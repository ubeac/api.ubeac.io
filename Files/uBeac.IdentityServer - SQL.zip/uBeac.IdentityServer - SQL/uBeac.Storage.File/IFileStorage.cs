﻿using System.Threading;
using System.Threading.Tasks;

namespace uBeac.Storage.File
{
    public interface IFileStorage
    {
        Task<string> ReadAllTextAsync(string filename, CancellationToken cancellationToken = default(CancellationToken));
        Task WriteTextAsync(string filename, string contents, CancellationToken cancellationToken = default(CancellationToken));
        Task<bool> ExistsAsync(string filename);
    }
}

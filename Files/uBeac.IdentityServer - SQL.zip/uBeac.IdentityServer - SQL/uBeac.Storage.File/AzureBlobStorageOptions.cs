﻿namespace uBeac.Storage.File
{
    public class AzureBlobStorageOptions
    {
        public string ConnectionString { get; set; }
        public string ContainerName { get; set; }
    }
}

﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.Threading;
using System.Threading.Tasks;

namespace uBeac.Storage.File
{
    public class AzureBlobStorage : IFileStorage
    {
        private AzureBlobStorageOptions _options;
        private CloudStorageAccount storageAccount;
        private CloudBlobClient blobClient;
        private CloudBlobContainer container;
        private CloudBlockBlob blob;

        public AzureBlobStorage(AzureBlobStorageOptions options)
        {
            _options = options;
            storageAccount = CloudStorageAccount.Parse(_options.ConnectionString);
            blobClient = storageAccount.CreateCloudBlobClient();
            container = blobClient.GetContainerReference(_options.ContainerName);
            container.CreateIfNotExistsAsync();
        }

        public async Task<bool> ExistsAsync(string filename)
        {
            blob = container.GetBlockBlobReference(filename);
            return await blob.ExistsAsync();
        }

        public async Task<string> ReadAllTextAsync(string filename,CancellationToken cancellationToken = default(CancellationToken))
        {
            blob = container.GetBlockBlobReference(filename);
            var contents = await blob.DownloadTextAsync();
            return contents;
        }

        public async Task WriteTextAsync(string filename, string contents, CancellationToken cancellationToken = default(CancellationToken))
        {
            blob = container.GetBlockBlobReference(filename);
            await blob.UploadTextAsync(contents);
        }

    }
}

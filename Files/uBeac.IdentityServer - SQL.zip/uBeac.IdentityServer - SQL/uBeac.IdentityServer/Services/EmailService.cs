﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using uBeac.Services;
using uBeac.Storage.File;

namespace uBeac.IdentityServer.Services
{
    public interface IEmailService
    {
        Task SendAccountConfirm(string emailAddress, string confirmationUrl);
        Task SendForgotPassword(string emailAddress, string callbackUrl);
    }

    public class EmailService : IEmailService
    {
        public const string ACCOUNTCONFIRM_BODY_FILENAME = "Email_ConfirmAccount_Body.txt";
        public const string ACCOUNTCONFIRM_SUBJECT_FILENAME = "Email_ConfirmAccount_Subject.txt";
        public const string RESETPASSWORD_BODY_FILENAME = "Email_ForgotPassword_Body.txt";
        public const string RESETPASSWORD_SUBJECT_FILENAME = "Email_ForgotPassword_Subject.txt";

        private readonly IEmailSender _emailSender;
        private readonly IFileStorage _fileStorage;

        private string accountConfirmSubject = "uBeac Email Confirmation";
        private string accountConfirmBody = "Please confirm your account by clicking this link: <a href='{HtmlEncoder.Default.Encode(link)}'>link</a>";
        private string forgotPasswordSubject = "uBeac Reset Password";
        private string forgotPasswordBody = "Please reset your password by clicking here: <a href='{callbackUrl}'>link</a>";

        public EmailService(IEmailSender emailSender, IFileStorage fileStorage)
        {
            emailSender.ThrowIfNull();
            fileStorage.ThrowIfNull();
            _emailSender = emailSender;
            _fileStorage = fileStorage;
            Init();
        }

        private void Init()
        {
            try
            {
                accountConfirmSubject = _fileStorage.ReadAllTextAsync(ACCOUNTCONFIRM_SUBJECT_FILENAME).Result;
                accountConfirmBody = _fileStorage.ReadAllTextAsync(ACCOUNTCONFIRM_BODY_FILENAME).Result;
                forgotPasswordSubject = _fileStorage.ReadAllTextAsync(RESETPASSWORD_SUBJECT_FILENAME).Result;
                forgotPasswordBody = _fileStorage.ReadAllTextAsync(RESETPASSWORD_BODY_FILENAME).Result;
            }
            catch (Exception)
            {

            }
        }

        public async Task SendAccountConfirm(string emailAddress, string confirmationUrl)
        {
            try
            {
                await _emailSender.SendEmailAsync(emailAddress, accountConfirmSubject, accountConfirmBody.Replace("[[url]]", confirmationUrl));
            }
            catch (Exception)
            {
            }
        }

        public async Task SendForgotPassword(string emailAddress, string callbackUrl)
        {
            try
            {
                await _emailSender.SendEmailAsync(emailAddress, forgotPasswordSubject, forgotPasswordBody.Replace("[[url]]", callbackUrl));
            }
            catch (Exception)
            {
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IdentityModel.Tokens.Jwt;
using uBeac.Configuration;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Repositories;
using uBeac.IdentityServer.Settings;

namespace uBeac.IdentityServer
{
    public static class IdentityServerBuilder
    {
        public static IServiceCollection AddIdentity(this IServiceCollection services, IConfiguration configuration, IHostingEnvironment env)
        {
            var appConfig = configuration.GetSection("AppConfig").Get<AppConfig>();
            appConfig.ThrowIfNull();

            var identityServerSettings = configuration.GetSection("IdentityServerSettings").Get<IdentityServerSettings>();
            identityServerSettings.ThrowIfNull();

            var identitySettings = configuration.GetSection("IdentitySettings").Get<IdentitySettings>();
            identitySettings.ThrowIfNull();

            services.AddSingleton(identityServerSettings);
            services.AddSingleton(identitySettings);
            
            var setupAction = new Action<IdentityOptions>(options =>
            {
                //todo: Amir, what is this for?
                options.Tokens.ChangePhoneNumberTokenProvider = "Phone";
                options.Password.RequireDigit = identitySettings.PasswordRequireDigit;
                options.Password.RequiredLength = identitySettings.PasswordRequiredLength;
                options.Password.RequireNonAlphanumeric = identitySettings.PasswordRequireNonAlphanumeric;
                options.Password.RequireUppercase = identitySettings.PasswordRequireUppercase;
                options.Password.RequireLowercase = identitySettings.PasswordRequireLowercase;
                options.Lockout.AllowedForNewUsers = identitySettings.LockoutAllowedForNewUsers;
                options.Lockout.MaxFailedAccessAttempts = identitySettings.LockoutMaxFailedAccessAttempts;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(identitySettings.LockoutDefaultLockoutTimeSpanMinutes);
            });
            
            services.AddDbContext<ApplicationDbContext>(options =>
                            options.UseSqlServer(configuration.GetConnectionString(identityServerSettings.ConnectionStringName)));

            services.AddIdentity<User, IdentityRole>(setupAction)
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();

            if (env.IsProduction())
            {
                services.AddAuthentication()
                                .AddGoogle("Google", options =>
                                {
                                    options.ClientId = identityServerSettings.GoogleClientId;
                                    options.ClientSecret = identityServerSettings.GoogleClientSecret;
                                })
                                .AddMicrosoftAccount("Microsoft", options =>
                                {
                                    options.ClientId = identityServerSettings.MicrosoftClientId;
                                    options.ClientSecret = identityServerSettings.MicrosoftClientSecret;
                                })
                                .AddTwitter("Twitter", option =>
                                {
                                    option.ConsumerKey = identityServerSettings.TwitterConsumerKey;
                                    option.ConsumerSecret = identityServerSettings.TwitterConsumerSecret;
                                })
                                .AddFacebook("Facebook", options =>
                                {
                                    options.AppId = identityServerSettings.FacebookAppId;
                                    options.AppSecret = identityServerSettings.FacebookAppSecret;
                                })
                                .AddGitHub(options =>
                                {
                                    options.ClientId = identityServerSettings.GitHubClientId;
                                    options.ClientSecret = identityServerSettings.GitHubClientSecret;

                                }).AddLinkedIn("LinedIn", options =>
                                {
                                    options.ClientId = identityServerSettings.LinedInClientId;
                                    options.ClientSecret = identityServerSettings.LinedInClientSecret;
                                });
            }

            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            services.AddAuthentication(options =>
            {
                //options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddIdentityServerAuthentication(options =>
                {
                    options.Authority = appConfig.Url;
                    options.RequireHttpsMetadata = false;
                    options.ApiName = appConfig.Name;
                });

            services.AddIdentityServer()
                .AddDeveloperSigningCredential()
                .AddInMemoryPersistedGrants()
                .AddInMemoryIdentityResources(identityServerSettings.GetIdentityResources())
                .AddInMemoryApiResources(identityServerSettings.GetApiResources())
                .AddInMemoryClients(identityServerSettings.GetClients())
                .AddAspNetIdentity<User>();

            return services;

        }


        public static IApplicationBuilder UseJWT(this IApplicationBuilder app)
        {

            app.Use(async (context, next) =>
            {
                if (!context.User.Identity.IsAuthenticated)
                {
                    var result = await context.AuthenticateAsync(JwtBearerDefaults.AuthenticationScheme);
                    if (result?.Principal != null)
                    {
                        context.User = result.Principal;
                    }
                }

                await next.Invoke();
            });

            return app;
        }

    }
}

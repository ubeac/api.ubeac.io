﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using uBeac.IdentityServer.Controllers;
using uBeac.Services;

namespace uBeac.IdentityServer
{
    public static class HelperExtensions
    {
        //public static string EmailConfirmationLink(this IUrlHelper urlHelper, string userId, string code, string scheme)
        //{
        //    return urlHelper.Action(
        //        action: nameof(UserController.ConfirmEmail),
        //        controller: "User",
        //        values: new { userId, code },
        //        protocol: scheme);
        //}

        //public static string ResetPasswordCallbackLink(this IUrlHelper urlHelper, string userId, string code, string scheme)
        //{
        //    return urlHelper.Action(
        //        action: nameof(UserController.ResetPassword),
        //        controller: "User",
        //        values: new { userId, code },
        //        protocol: scheme);
        //}

        //public static Task SendEmailConfirmationAsync(this IEmailSender emailSender, string email, string link)
        //{
        //    return emailSender.SendEmailAsync(email, "uBeac Email Confirmation",
        //        $"Please confirm your account by clicking this link: <a href='{HtmlEncoder.Default.Encode(link)}'>link</a>");
        //}

    }
}

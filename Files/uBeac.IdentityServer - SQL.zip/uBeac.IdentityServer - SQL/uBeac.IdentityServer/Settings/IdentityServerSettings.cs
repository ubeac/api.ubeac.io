﻿using System.Collections.Generic;

namespace uBeac.IdentityServer.Settings
{
    public class IdentityServerSettings
    {
        public string ConnectionStringName { get; set; }
        public string GoogleClientId { get; set; }
        public string GoogleClientSecret { get; set; }
        public string MicrosoftClientId { get; set; }
        public string MicrosoftClientSecret { get; set; }
        public string TwitterConsumerKey { get; set; }
        public string TwitterConsumerSecret { get; set; }
        public string FacebookAppId { get; set; }
        public string FacebookAppSecret { get; set; }
        public string GitHubClientId { get; set; }
        public string GitHubClientSecret { get; set; }
        public string LinedInClientId { get; set; }
        public string LinedInClientSecret { get; set; }
        public List<ClientSettings> Clients { get; set; }
        public List<string> ApiResources { get; set; }
        public List<string> IdentityResources { get; set; }
        public string PostConfirmEmailUrl { get; set; }
        public string PostForgotPasswordUrl { get; set; }
    }
}

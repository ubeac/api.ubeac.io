﻿using IdentityServer4.Models;
using System.Collections.Generic;
using System.Linq;

namespace uBeac.IdentityServer.Settings
{
    public static class IdentityServerSettingsExtentions
    {

        public static IEnumerable<ApiResource> GetApiResources(this IdentityServerSettings _identityServerSettings)
        {
            _identityServerSettings.ApiResources.ThrowIfNull();
            return _identityServerSettings.ApiResources.Select(item => new ApiResource(item));
        }

        public static IEnumerable<IdentityResource> GetIdentityResources(this IdentityServerSettings _identityServerSettings)
        {
            _identityServerSettings.IdentityResources.ThrowIfNull();
            return _identityServerSettings.IdentityResources.Select(item => GetIdentityResource(item));
        }

        public static IEnumerable<Client> GetClients(this IdentityServerSettings _identityServerSettings)
        {
            _identityServerSettings.Clients.ThrowIfNull();
            return _identityServerSettings.Clients.Select(item => GetClient(item));
        }

        private static Client GetClient(ClientSettings _clientSettings)
        {
            var result = new Client()
            {
                ClientId = _clientSettings.ClientId,
                ClientName = _clientSettings.ClientName,
                AllowedGrantTypes = _clientSettings.AllowedGrantTypes.Split(" "),
                AllowAccessTokensViaBrowser = _clientSettings.AllowAccessTokensViaBrowser,
                RequireConsent = _clientSettings.RequireConsent,
                RedirectUris = _clientSettings.RedirectUris,
                PostLogoutRedirectUris = _clientSettings.PostLogoutRedirectUris,
                AllowedCorsOrigins = _clientSettings.AllowedCorsOrigins,
                AllowedScopes = _clientSettings.AllowedScopes.Split(" ")
            };

            if (_clientSettings.ClientSecrets != null)
            {
                _clientSettings.ClientSecrets.ForEach(secret => result.ClientSecrets.Add(new Secret(secret.Sha256())));
            }
            return result;

        }

        private static IdentityResource GetIdentityResource(string resourceName)
        {
            switch (resourceName)
            {
                case "openid":
                    return new IdentityResources.OpenId();
                case "profile":
                    return new IdentityResources.Profile();
                case "email":
                    return new IdentityResources.Email();
                case "phone":
                    return new IdentityResources.Phone();
                case "address":
                    return new IdentityResources.Address();
                case "roles":
                    return new IdentityResource("roles", "Roles for the user", new List<string> { "role" });

                default:
                    return new IdentityResource(resourceName, resourceName, new List<string> { resourceName });
            }

        }

    }
}

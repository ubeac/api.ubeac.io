﻿namespace uBeac.IdentityServer.Settings
{
    public class MailServerSettings
    {
        public string Name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Host { get; set; }
        public int Port { get; set; }
        public string SenderEmail { get; set; }
        public string SenderDisplayName { get; set; }
        public bool EnableSsl { get; set; }
    }
}

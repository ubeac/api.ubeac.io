﻿using System.Collections.Generic;

namespace uBeac.IdentityServer.Settings
{
    public class ClientSettings
    {
        public string ClientId { get; set; }
        public string ClientName { get; set; }
        public List<string> ClientSecrets { get; set; }
        public string AllowedGrantTypes { get; set; }
        public bool AllowAccessTokensViaBrowser { get; set; }
        public bool RequireConsent { get; set; }
        public List<string> RedirectUris { get; set; }
        public List<string> PostLogoutRedirectUris { get; set; }
        public List<string> AllowedCorsOrigins { get; set; }
        public string AllowedScopes { get; set; }
    }
}

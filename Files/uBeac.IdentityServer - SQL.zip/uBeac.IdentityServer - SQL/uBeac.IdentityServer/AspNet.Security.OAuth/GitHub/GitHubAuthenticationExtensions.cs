﻿using AspNet.Security.OAuth.GitHub;
using Microsoft.AspNetCore.Authentication;
using System;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>
    /// Extension methods to add GitHub authentication capabilities to an HTTP application pipeline.
    /// </summary>
    public static class GitHubAuthenticationExtensions
    {
        /// <summary>
        /// Adds <see cref="GitHubAuthenticationHandler"/> to the specified
        /// <see cref="AuthenticationBuilder"/>, which enables GitHub authentication capabilities.
        /// </summary>
        /// <param name="builder">The authentication builder.</param>
        /// <returns>The <see cref="AuthenticationBuilder"/>.</returns>
        public static AuthenticationBuilder AddGitHub( this AuthenticationBuilder builder)
        {
            return builder.AddGitHub(GitHubAuthenticationDefaults.AuthenticationScheme, options => { });
        }

        /// <summary>
        /// Adds <see cref="GitHubAuthenticationHandler"/> to the specified
        /// <see cref="AuthenticationBuilder"/>, which enables GitHub authentication capabilities.
        /// </summary>
        /// <param name="builder">The authentication builder.</param>
        /// <param name="configuration">The delegate used to configure the OpenID 2.0 options.</param>
        /// <returns>The <see cref="AuthenticationBuilder"/>.</returns>
        public static AuthenticationBuilder AddGitHub(
             this AuthenticationBuilder builder,
             Action<GitHubAuthenticationOptions> configuration)
        {
            return builder.AddGitHub(GitHubAuthenticationDefaults.AuthenticationScheme, configuration);
        }

        /// <summary>
        /// Adds <see cref="GitHubAuthenticationHandler"/> to the specified
        /// <see cref="AuthenticationBuilder"/>, which enables GitHub authentication capabilities.
        /// </summary>
        /// <param name="builder">The authentication builder.</param>
        /// <param name="scheme">The authentication scheme associated with this instance.</param>
        /// <param name="configuration">The delegate used to configure the GitHub options.</param>
        /// <returns>The <see cref="AuthenticationBuilder"/>.</returns>
        public static AuthenticationBuilder AddGitHub(
             this AuthenticationBuilder builder,  string scheme,
             Action<GitHubAuthenticationOptions> configuration)
        {
            return builder.AddGitHub(scheme, GitHubAuthenticationDefaults.DisplayName, configuration);
        }

        /// <summary>
        /// Adds <see cref="GitHubAuthenticationHandler"/> to the specified
        /// <see cref="AuthenticationBuilder"/>, which enables GitHub authentication capabilities.
        /// </summary>
        /// <param name="builder">The authentication builder.</param>
        /// <param name="scheme">The authentication scheme associated with this instance.</param>
        /// <param name="caption">The optional display name associated with this instance.</param>
        /// <param name="configuration">The delegate used to configure the GitHub options.</param>
        /// <returns>The <see cref="AuthenticationBuilder"/>.</returns>
        public static AuthenticationBuilder AddGitHub(
             this AuthenticationBuilder builder,
             string scheme, string caption,
             Action<GitHubAuthenticationOptions> configuration)
        {
            return builder.AddOAuth<GitHubAuthenticationOptions, GitHubAuthenticationHandler>(scheme, caption, configuration);
        }
    }
}

﻿using Microsoft.AspNetCore.Identity;

namespace uBeac.IdentityServer.Models
{
    public class User : IdentityUser
    {
    }
    
}

﻿//using Microsoft.AspNetCore.Identity;
//using System.Collections.Generic;

//namespace uBeac.IdentityServer.Models
//{
//    public class Role : IdentityRole
//    {
//        public List<RoleClaim> Claims { get; set; }

//        public Role()
//        {
//            Claims = new List<RoleClaim>();
//        }

//    }

//    public class RoleClaim : IdentityRoleClaim<string>
//    {
//    }
//}

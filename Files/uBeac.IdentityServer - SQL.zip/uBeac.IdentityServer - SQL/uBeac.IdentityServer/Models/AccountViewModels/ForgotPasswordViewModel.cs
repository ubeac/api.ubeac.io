﻿using System.ComponentModel.DataAnnotations;

namespace uBeac.IdentityServer.Models.AccountViewModels
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}

﻿namespace uBeac.IdentityServer.Models
{
    public class UserProfile
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int EmployeeCode { get; set; }
        public int UnitCode { get; set; }
        public int UnitType { get; set; }
    }
}

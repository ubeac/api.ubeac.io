﻿namespace uBeac.IdentityServer.Models
{
    public class ResetPasswordInputModel
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public string ConfirmPassword { get; set; }
        public string Code { get; set; }
    }
}

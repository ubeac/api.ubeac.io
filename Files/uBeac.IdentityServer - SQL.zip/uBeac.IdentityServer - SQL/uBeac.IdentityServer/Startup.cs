﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using uBeac.Common.Middlewares;
using uBeac.Configuration;
using uBeac.IdentityServer.Repositories;
using uBeac.IdentityServer.Services;
using uBeac.IdentityServer.Settings;
using uBeac.Services;
using uBeac.Storage.File;

namespace uBeac.IdentityServer
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public IHostingEnvironment Environment { get; }
        public AppConfig AppConfig { get; }

        public Startup(IConfiguration configuration, IHostingEnvironment environment)
        {
            Configuration = configuration;
            Environment = environment;
            AppConfig = Configuration.GetSection("AppConfig").Get<AppConfig>();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            // Base application config
            services.AddSingleton(AppConfig);

            //// Azure BLOB file storage
            var azureBlobStorageOptions = Configuration.GetSection("AzureBlobStorageOptions").Get<AzureBlobStorageOptions>();
            services.AddSingleton(azureBlobStorageOptions);
            services.AddSingleton<IFileStorage, AzureBlobStorage>();

            // mail server config
            var mailServerSettings = Configuration.GetSection("MailServerSettings").Get<MailServerSettings>();
            services.AddSingleton(mailServerSettings);
            services.AddSingleton<IEmailSender, EmailSender>();
            services.AddSingleton<IEmailService, EmailService>();

            // identity server config
            services.AddIdentity(Configuration, Environment);
            
            // swagger config
            services.AddSwaggerGen(c =>
              {
                  c.SwaggerDoc(AppConfig.Version, new Info { Title = AppConfig.Name, Version = AppConfig.Version });
              });

            // CORS config
            services.AddCors(options =>
            {
                options.AddPolicy("AppConfigCors", policy =>
                {
                    foreach (string item in AppConfig.CorsOrigins)
                    {
                        policy.WithOrigins(item).AllowAnyHeader().AllowAnyMethod();
                    }
                });
            });
            
            services.AddResponseCompression();

            // adding mvc
            services.AddMvc();

            services.AddScoped<IDbInitializer, DbInitializer>();
            
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IDbInitializer dbInitializer)
        {
            if (Environment.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }

            app
                .UseMiddleware(typeof(ExceptionHandlingMiddleware))
                .UseResponseCompression()
                .UseCors("AppConfigCors")
                .UseStaticFiles()
                .UseIdentityServer()
                .UseJWT()
                .UseSwagger()
                .UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/" + AppConfig.Version + "/swagger.json", AppConfig.Name);
                })
                .UseMvc(routes =>
                {
                    routes.MapRoute(
                        name: "default",
                        template: "{controller=Home}/{action=Index}/{id?}");
                });

            dbInitializer.Init();
        }
    }
}

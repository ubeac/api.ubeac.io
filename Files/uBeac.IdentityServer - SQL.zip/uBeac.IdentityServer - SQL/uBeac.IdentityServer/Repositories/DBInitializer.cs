﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;
using System.Linq;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories
{
    public interface IDbInitializer
    {
        void Init();
    }

    public class DbInitializer : IDbInitializer
    {

        UserManager<User> _userManager;
        RoleManager<IdentityRole> _roleManager;

        public DbInitializer(UserManager<User> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public void Init()
        {
            if (!_roleManager.Roles.Any())
            {
                var roles = Roles();
                foreach (var role in roles)
                {
                    var roleResult = _roleManager.CreateAsync(role).Result;
                }
                var userResult = _userManager.CreateAsync(AdminUser(), "123").Result;
            }
        }

        private IEnumerable<IdentityRole> Roles()
        {
            return new List<IdentityRole>
            {
                new IdentityRole(Constants.ROLE_ADMIN),
                new IdentityRole(Constants.ROLE_NORMAL_USERS),
                new IdentityRole(Constants.ROLE_REGISTERED_EXTERNAL),
                new IdentityRole(Constants.ROLE_REGISTERED_INTERNAL)
            };
        }

        private User AdminUser()
        {
            return new User()
            {
                Email = "ap@momentaj.com",
                UserName = "ap@momentaj.com"
            };
        }

    }

}

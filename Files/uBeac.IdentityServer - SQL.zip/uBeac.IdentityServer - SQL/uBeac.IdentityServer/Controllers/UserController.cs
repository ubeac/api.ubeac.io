﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using uBeac.Common.Filters;
using uBeac.Filters;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Services;
using uBeac.IdentityServer.Settings;
using uBeac.Services;
using uBeac.Storage.File;

namespace uBeac.IdentityServer.Controllers
{
    [Authorize]
    [Route("api/[controller]/[action]")]
    [TypeFilter(typeof(ResultSetResponseCodeFilter))]
    [TypeFilter(typeof(ModelStateValidationAsyncActionFilter))]
    public class UserController : ControllerBase
    {

        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IEmailService _emailService;
        private readonly ILogger _logger;
        private readonly IdentityServerSettings _identityServerSettings;
        private readonly IFileStorage _fileStorage;

        public UserController(UserManager<User> userManager, SignInManager<User> signInManager, IEmailService emailService, ILogger<UserController> logger, IdentityServerSettings identityServerSettings, IFileStorage fileStorage)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _emailService = emailService;
            _logger = logger;
            _identityServerSettings = identityServerSettings;
            _fileStorage = fileStorage;
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<ResultSet<string>> Register([FromBody]  UserRegisterInputModel model)
        {

            var resultSet = new ResultSet<string>();

            User user = new User { UserName = model.Email, Email = model.Email };

            var result = await _userManager.CreateAsync(user, model.Password);
            if (result.Succeeded)
            {

                await _userManager.AddToRoleAsync(user, Constants.ROLE_NORMAL_USERS);
                await _userManager.AddToRoleAsync(user, Constants.ROLE_REGISTERED_INTERNAL);

                if (user.UserName.ToLower().EndsWith("@momentaj.com"))
                    await _userManager.AddToRoleAsync(user, Constants.ROLE_ADMIN);

                var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
                var confirmUrl = Url.Action(action: nameof(UserController.ConfirmEmail), controller: "User", values: new { user.Id, code }, protocol: Request.Scheme);
                await _emailService.SendAccountConfirm(model.Email, HtmlEncoder.Default.Encode(confirmUrl));

                resultSet.Data = user.Id;
            }
            else
            {
                foreach (var item in result.Errors)
                {
                    resultSet.AddError(new Error(item.Code, item.Description));
                    resultSet.Code = ResponseCodes.BadRequest;
                }
            }
            return resultSet;

        }

        [HttpPost]
        public async Task<ResultSet<List<KeyValuePair<string, string>>>> Claims()
        {
            var claims = (from p in User.Claims select new KeyValuePair<string, string>(p.Type, p.Value)).ToList();
            var resultSet = new ResultSet<List<KeyValuePair<string, string>>>(claims);
            return await Task.FromResult(resultSet);
        }

        [HttpPost]
        public async Task<ResultSet<bool>> ChangePassword([FromBody]  UserChangePasswordInputModel model)
        {
            var resultSet = new ResultSet<bool>(false);

            var user = await _userManager.GetUserAsync(HttpContext.User);
            if (user is null)
            {
                resultSet.AddError(new Error("InvalidClaims", "User is not logged in!"));
                return resultSet;
            }

            var result = await _userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);
            resultSet.Data = result.Succeeded;

            if (!result.Succeeded)
            {
                foreach (var item in result.Errors)
                {
                    resultSet.AddError(new Error(item.Code, item.Description));
                    resultSet.Code = ResponseCodes.BadRequest;
                }
            }

            return resultSet;

        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> ConfirmEmail(string userId, string code)
        {
            userId.ThrowIfNull();
            code.ThrowIfNull();

            var user = await _userManager.FindByIdAsync(userId);
            if (user is null)
            {
                throw new ApplicationException($"Unable to load user with ID '{userId}'.");
            }
            var result = await _userManager.ConfirmEmailAsync(user, code);
            if (result.Succeeded)
            {
                return RedirectPermanent(_identityServerSettings.PostConfirmEmailUrl);
            }
            throw new ApplicationException($"Unable to update email confirmation for user with ID '{userId}'.");
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<ResultSet<bool>> ForgotPassword([FromBody] UserForgotPasswordInputModel model)
        {
            var resultSet = new ResultSet<bool>(true);
            var user = await _userManager.FindByEmailAsync(model.Email);

            if (user is null)
            {
                resultSet.AddError(new Error("EmailNotExist", "Email address does not exist!"));
                resultSet.Data = false;
            }

            if (!(await _userManager.IsEmailConfirmedAsync(user)))
            {
                resultSet.AddError(new Error("EmailNotConfirmed", "Email address is not confirmed!"));
                resultSet.Data = false;
            }

            if (resultSet.Errors.Count == 0)
            {
                var code = await _userManager.GeneratePasswordResetTokenAsync(user);
                var parametersToAdd = new Dictionary<string, string> {
                    { "email", user.Email} ,
                    { "code", code }
                };

                var callbackUrl = QueryHelpers.AddQueryString(_identityServerSettings.PostForgotPasswordUrl, parametersToAdd);
                await _emailService.SendForgotPassword(user.Email, callbackUrl);

            }

            return resultSet;
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<ResultSet<bool>> ResetPassword([FromBody]UserResetPasswordInputModel model)
        {
            var resultSet = new ResultSet<bool>(false);

            var user = await _userManager.GetUserAsync(HttpContext.User);
            if (user is null)
            {
                resultSet.AddError(new Error("InvalidClaims", "User is not logged in!"));
                return resultSet;
            }

            var result = await _userManager.ResetPasswordAsync(user, model.Code, model.Password);
            if (result.Succeeded)
            {
                resultSet.Code = ResponseCodes.OK;
            }
            else
            {
                foreach (var item in result.Errors)
                {
                    resultSet.AddError(new Error(item.Code, item.Description));
                    resultSet.Code = ResponseCodes.BadRequest;
                }
            }

            return resultSet;
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<ResultSet<bool>> Logout()
        {
            var resultSet = new ResultSet<bool>(true);
            await _signInManager.SignOutAsync();
            return resultSet;
        }

        [HttpPost]
        public async Task<ResultSet<bool>> ResendEmail()
        {
            var resultSet = new ResultSet<bool>(false);

            var user = await _userManager.GetUserAsync(HttpContext.User);
            if (user is null)
            {
                resultSet.AddError(new Error("InvalidClaims", "User is not logged in!"));
                return resultSet;
            }

            var code = await _userManager.GenerateEmailConfirmationTokenAsync(user);
            var confirmUrl = Url.Action(action: nameof(UserController.ConfirmEmail), controller: "User", values: new { user.Id, code }, protocol: Request.Scheme);
            await _emailService.SendAccountConfirm(user.Email, HtmlEncoder.Default.Encode(confirmUrl));

            return resultSet;
        }

    }

    public class UserRegisterInputModel
    {

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Password { get; set; }

    }

    public class UserChangePasswordInputModel
    {

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string NewPassword { get; set; }

    }

    public class UserForgotPasswordInputModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }

    public class UserResetPasswordInputModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        public string Code { get; set; }
    }

}

﻿var config = {
    authority: "http://idsrv.ubeac.io/",
    //authority: "http://localhost:60000/",
    client_id: "AdminUIClientRO",
    client_secret: "secret",
    response_type: "password",
    scope: "openid profile email phone address roles IdentityServer",
};

var identityUrls = {
    register: config.authority + "api/user/register",
    login: config.authority + "connect/token",
    logout: config.authority + "api/user/logout",
    revoke: config.authority + "connect/revocation",
    userinfo: config.authority + "connect/userinfo",
    userclaims: config.authority + "api/user/claims",
    changepassword: config.authority + "api/user/changepassword",
    forgotpassword: config.authority + "api/user/forgotpassword",
    resetpassword: config.authority + "api/user/resetpassword",
    resendemail: config.authority + "api/user/resendemail"
};

document.getElementById('response').innerText = '';
function log() {

    Array.prototype.forEach.call(arguments, function (msg) {
        if (msg instanceof Error) {
            msg = "Error: " + msg.message;
        }
        else if (typeof msg !== 'string') {
            msg = JSON.stringify(msg, null, 2);
        }
        document.getElementById('response').innerHTML += msg + '\r\n';
    });
}

function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function getUserInfo() {
    setStorage("user_info", null);
    var userToken = getStorage("user_token");
    if (userToken && userToken.access_token) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function (e) {
            var response_data = JSON.parse(xhr.response);
            log(identityUrls.userinfo, xhr.status, response_data);
            if (xhr.status === 200) {
                setStorage("user_info", response_data);
                document.getElementById('userinfo').innerHTML = JSON.stringify(getStorage("user_info")) + '\r\n';
            }
        }
        xhr.open("POST", identityUrls.userinfo);
        xhr.setRequestHeader("Authorization", "Bearer " + userToken.access_token);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send("");
    }
}

function getUserClaims() {
    setStorage("user_claims", null);
    var userToken = getStorage("user_token");
    if (userToken && userToken.access_token) {
        var xhr = new XMLHttpRequest();
        xhr.onload = function (e) {
            var response_data = JSON.parse(xhr.response);
            log(identityUrls.userinfo, xhr.status, response_data);
            if (xhr.status === 200) {
                setStorage("user_claims", response_data);
                document.getElementById('userclaims').innerHTML = JSON.stringify(getStorage("user_claims")) + '\r\n';
            }
        }
        xhr.open("POST", identityUrls.userclaims);
        xhr.setRequestHeader("Authorization", "Bearer " + userToken.access_token);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send("");
    }
}

function setStorage(key, value) {
    if (value) {
        localStorage.setItem(key, JSON.stringify(value));
    }
    else {
        if (localStorage.getItem(key))
            localStorage.removeItem(key);
    }
}

function getStorage(key) {
    var result = localStorage.getItem(key);
    if (result) {
        result = JSON.parse(result);
    }
    return result;
}

function send_post(url, data) {
    mgr.getUser().then(function (user) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", url);
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onload = function () {
            log(xhr.status, JSON.parse(xhr.responseText));
        };
        xhr.setRequestHeader("Authorization", "Bearer " + user.access_token);
        xhr.send(JSON.stringify(data));
    });
}

document.getElementById("register").addEventListener("click", register, false);
function register() {
    var data = {
        email: document.getElementById("register_email").value,
        password: document.getElementById("register_password").value
    };

    var xhr = new XMLHttpRequest();
    xhr.open("POST", identityUrls.register);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onload = function () {
        var response_data = JSON.parse(xhr.response);
        log(identityUrls.register, xhr.status, response_data);
        if (xhr.status === 200) {
            getToken(data.email, data.password);
            updateUI();
        }
    };

    xhr.send(JSON.stringify(data));
}

document.getElementById("forgotpassword").addEventListener("click", forgotpassword, false);
function forgotpassword() {
    var data = {
        email: document.getElementById("forgotpassword_email").value
    };

    var xhr = new XMLHttpRequest();
    xhr.open("POST", identityUrls.forgotpassword);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onload = function () {
        var response_data = JSON.parse(xhr.response);
        log(identityUrls.forgotpassword, xhr.status, response_data);
    };

    xhr.send(JSON.stringify(data));
}

document.getElementById("login").addEventListener("click", login, false);
function login() {
    var email = document.getElementById("login_email").value;
    var password = document.getElementById("login_password").value;
    getToken(email, password);
}

document.getElementById("logout").addEventListener("click", logout, false);
function logout() {
    setStorage("user_token", null);
    setStorage("user_info", null);
    setStorage("user_claims", null);
    updateUI();

    var xhr = new XMLHttpRequest();
    xhr.open("POST", identityUrls.logout);

    xhr.onload = function () {
        var response_data = JSON.parse(xhr.response);
        log(identityUrls.logout, xhr.status, response_data);
    };

    xhr.send("");

}

document.getElementById("changepassword").addEventListener("click", changepassword, false);
function changepassword() {
    var data = {
        oldpassword: document.getElementById("changepassword_oldpassword").value,
        newpassword: document.getElementById("changepassword_newpassword").value
    };

    var userToken = getStorage("user_token");
    if (userToken && userToken.access_token) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", identityUrls.changepassword);
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onload = function () {
            var response_data = JSON.parse(xhr.response);
            log(identityUrls.changepassword, xhr.status, response_data);
            if (xhr.status === 200) {
                logout();
            }
        };
        xhr.setRequestHeader("Authorization", "Bearer " + userToken.access_token);
        xhr.send(JSON.stringify(data));
    }
}

document.getElementById("resendemail").addEventListener("click", resendemail, false);
function resendemail() {

    var userToken = getStorage("user_token");
    if (userToken && userToken.access_token) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", identityUrls.resendemail);
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onload = function () {
            var response_data = JSON.parse(xhr.response);
            log(identityUrls.resendemail, xhr.status, response_data);
            if (xhr.status === 200) {
                
            }
        };
        xhr.setRequestHeader("Authorization", "Bearer " + userToken.access_token);
        xhr.send(JSON.stringify(""));
    }
}

document.getElementById("resetpassword").addEventListener("click", resetpassword, false);
function resetpassword() {

    /// Reset password callback data from querystring
    var code = getParameterByName("code");
    var email = getParameterByName("email");
    if (code == null || email == null) {
        log("Invalid reset password data!");
        console.error("Invalid reset password data!");
    }
    var data = {
        code: code,
        email: email,
        password: document.getElementById("resetpassword_password").value
    };

    var xhr = new XMLHttpRequest();
    xhr.open("POST", identityUrls.resetpassword);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onload = function () {
        var response_data = JSON.parse(xhr.response);
        log(identityUrls.resetpassword, xhr.status, response_data);
        if (xhr.status === 200) {
            getToken(data.email, data.password);
        }
    };
    xhr.send(JSON.stringify(data));

}

function getToken(email, password) {
    var xhr = new XMLHttpRequest();
    xhr.onload = function (e) {
        var response_data = JSON.parse(xhr.response);
        log(identityUrls.login, xhr.status, response_data);
        if (xhr.status === 200 && response_data.access_token) {
            setStorage("user_token", response_data);
            getUserInfo();
            getUserClaims();
            updateUI();
            //revokeToken(response_data.access_token);
        }
    }
    xhr.open("POST", identityUrls.login);
    var data = {
        username: email,
        password: password,
        grant_type: config.response_type,
        scope: config.scope
    };
    var body = "";
    for (var key in data) {
        if (body.length) {
            body += "&";
        }
        body += key + "=";
        body += encodeURIComponent(data[key]);
    }
    xhr.setRequestHeader("Authorization", "Basic " + btoa(config.client_id + ":" + config.client_secret));
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(body);
}

function updateUI() {
    document.getElementById('userinfo').innerText = '';
    document.getElementById('userclaims').innerText = '';

    var userAuthenticated = getStorage("user_token");
    document.getElementById("login").disabled = userAuthenticated;
    document.getElementById("register").disabled = userAuthenticated;
    document.getElementById("logout").disabled = !userAuthenticated;
    document.getElementById("resendemail").disabled = !userAuthenticated;
    document.getElementById("changepassword").disabled = !userAuthenticated;
    document.getElementById("forgotpassword").disabled = userAuthenticated;
    if (userAuthenticated) {
        document.getElementById('userinfo').innerHTML = JSON.stringify(getStorage("user_info")) + '\r\n';
        document.getElementById('userclaims').innerHTML = JSON.stringify(getStorage("user_claims")) + '\r\n';
    }
    var code = getParameterByName("code");
    var email = getParameterByName("email");
    if (code == null || email == null) {
        document.getElementById("resetpassword").disabled = true;
        document.getElementById("resetpassword_password").disabled = true;
    }
    else
    {
        document.getElementById("resetpassword").disabled = false;
        document.getElementById("resetpassword_password").disabled = false;
        document.getElementById('resetpassword_code').value = getParameterByName("code");
        document.getElementById('resetpassword_email').value = getParameterByName("email");
    }
}

updateUI();

//function revokeToken(token) {
//    var xhr = new XMLHttpRequest();
//    xhr.onload = function (e) {
//        log(xhr.status, xhr.response);
//        console.log(xhr.response);
//    }
//    xhr.open("POST", identityUrls.revoke);
//    var data = {
//        token: token,
//        token_type_hint: "access_token" //refresh_token
//    };
//    var body = "";
//    for (var key in data) {
//        if (body.length) {
//            body += "&";
//        }
//        body += key + "=";
//        body += encodeURIComponent(data[key]);
//    }
//    xhr.setRequestHeader("Authorization", "Basic " + btoa(config.client_id + ":" + config.client_secret));
//    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
//    xhr.send(body);
//}

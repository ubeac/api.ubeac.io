﻿/// <reference path="oidc-client.js" />

// IdentityServer settings
const IDENTITY_URL = "http://sso.ubeac.io/";
const IDENTITY_CLIENT_ID = "AdminUIClient";
const IDENTITY_REDIRECT_URI = location.protocol + '//' + location.host + "/callback.html";
const IDENTITY_POST_LOGOUT_REDIRECT_URI = location.protocol + '//' + location.host + "/index.html";
const IDENTITY_RESPONSE_TYPE = "id_token token";
const IDENTITY_SCOPE = "openid profile email phone address AdminApi Roles IdentityServer Api";

// User management back-end settings
const URL_GET_CURRENT_USER_CLAIMS = IDENTITY_URL + "User/GetCurrentClaims";
const URL_GET_CURRENT_USER_INFO = IDENTITY_URL + "connect/userinfo";
const URL_GET_CURRENT_USER_ADD = IDENTITY_URL + "User/Add";

const URL_CUSTOM_API_URL = "http://adminapi.ubeac.io/api/manufacturer/getall";

function log() {
    document.getElementById('results').innerText = '';

    Array.prototype.forEach.call(arguments, function (msg) {
        if (msg instanceof Error) {
            msg = "Error: " + msg.message;
        }
        else if (typeof msg !== 'string') {
            msg = JSON.stringify(msg, null, 2);
        }
        document.getElementById('results').innerHTML += msg + '\r\n';
    });
}

document.getElementById("login").addEventListener("click", login, false);
document.getElementById("logout").addEventListener("click", logout, false);
document.getElementById("claims").addEventListener("click", claims, false);
document.getElementById("userinfo").addEventListener("click", userinfo, false);
document.getElementById("createUser").addEventListener("click", createUser, false);

document.getElementById("api").addEventListener("click", api, false);



var config = {
    authority: IDENTITY_URL,
    client_id: IDENTITY_CLIENT_ID,
    redirect_uri: IDENTITY_REDIRECT_URI,
    response_type: IDENTITY_RESPONSE_TYPE,
    scope: IDENTITY_SCOPE,
    post_logout_redirect_uri: IDENTITY_POST_LOGOUT_REDIRECT_URI
};
var mgr = new Oidc.UserManager(config);

mgr.getUser().then(function (user) {
    if (user) {
        log("User logged in", JSON.stringify(user.profile, null, 2));
    }
    else {
        log("User not logged in");
    }
});

function send_get(url) {
    mgr.getUser().then(function (user) {
        var xhr = new XMLHttpRequest();
        console.log(url);
        xhr.open("GET", url);
        xhr.onload = function () {
            log(xhr.status, JSON.parse(xhr.responseText));
        };
        xhr.setRequestHeader("Authorization", "Bearer " + user.access_token);
        xhr.send();
    });
}

function send_post(url, data) {
    mgr.getUser().then(function (user) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", url);
        xhr.setRequestHeader("Content-Type", "application/json");

        xhr.onload = function () {
            log(xhr.status, JSON.parse(xhr.responseText));
        };
        xhr.setRequestHeader("Authorization", "Bearer " + user.access_token);
        xhr.send(JSON.stringify(data));
    });
}

function login() {
    mgr.signinRedirect();
}

function logout() {
    mgr.signoutRedirect();
}

function userinfo() {
    send_get(URL_GET_CURRENT_USER_INFO);
}

function claims() {
    send_get(URL_GET_CURRENT_USER_CLAIMS);
}

function api() {
    send_get(URL_CUSTOM_API_URL);
}

function createUser() {
    var data = {
        username: document.getElementById("username").value,
        firstname: document.getElementById("firstname").value,
        lasttname: document.getElementById("lastname").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    };
    send_post(URL_GET_CURRENT_USER_ADD, data);

}


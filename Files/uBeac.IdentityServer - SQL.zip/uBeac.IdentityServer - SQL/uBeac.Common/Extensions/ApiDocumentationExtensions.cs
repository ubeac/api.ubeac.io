﻿using Microsoft.AspNetCore.Builder;
using Swashbuckle.AspNetCore.Swagger;
using uBeac.Configuration;

namespace Microsoft.Extensions.DependencyInjection
{
    public static  class ApiDocumentationExtensions
    {
        public static IServiceCollection AddApiDocumantation(this IServiceCollection services, AppConfig AppConfig)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(AppConfig.Version, new Info { Title = AppConfig.Name, Version = AppConfig.Version });
            });

            return services;
        }

        public static IApplicationBuilder UseApiDocumantation(this IApplicationBuilder app, AppConfig AppConfig)
        {
            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/" + AppConfig.Version + "/swagger.json", AppConfig.Name);
            });

            return app;

        }
    }
}

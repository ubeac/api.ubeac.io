﻿using Microsoft.AspNetCore.Builder;
using uBeac.Common.Middlewares;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ApiExceptionHandlingExtensions
    {
        public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder app)
        {
            return app.UseMiddleware(typeof(ExceptionHandlingMiddleware));
        }
    }
}

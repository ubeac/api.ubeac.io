﻿using System;
using System.Collections.Generic;

namespace uBeac
{
    public interface IResultSet<TResult>: IResultSet
    {
        TResult Data { get; set; }
    }

    public interface IResultSet 
    {
        ResponseCodes Code { get; set; }
        List<Error> Errors { get; }
    }

    public class ResultSet<TResult>: IResultSet<TResult>
    {
        public ResponseCodes Code { get; set; }
        public TResult Data { get; set; }
        public List<Error> Errors { get; }

        public ResultSet()
        {
            Code = ResponseCodes.OK;
            Errors = new List<Error>();
        }

        public ResultSet(TResult value) : this()
        {
            Code = ResponseCodes.OK;
            Data = value;
        }

        public ResultSet(Exception exception) : this()
        {
            Code = ResponseCodes.UnhandledException;
            Errors.Add(new Error(exception));
        }

        public void AddError(Error error)
        {
            Code = ResponseCodes.BadRequest;
            Errors.Add(error);
        }

        public void AddError(Exception ex)
        {
            Errors.Add(new Error(ex));
        }

    }
}

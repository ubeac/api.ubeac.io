﻿namespace uBeac
{
    public enum ResponseCodes
    {
        OK = 200,
        BadRequest = 400,
        UnhandledException = 500
    }
}

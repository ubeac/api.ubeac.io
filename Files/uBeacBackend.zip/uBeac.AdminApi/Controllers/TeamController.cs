﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.AdminApi.Controllers
{
    using Result = ApiResult<Team>;

    public class TeamController : BaseEntityController<Team>
    {
        protected readonly IMapper Mapper;        
        private ITeamService _service;
        public TeamController(IMapper mapper, ITeamService service) : base(service)
        {
            _service = service;
            Mapper = mapper;
        }

        [HttpPut]
        public async Task<Result> Add([FromBody] TeamInputModel model)
        {
            return Result.GetOK(await _service.AddAsync(Mapper.Map<Team>(model)));
        }

        [HttpPost]
        public async Task<Result> Update([FromBody] TeamInputModel model)
        {
            return Result.GetOK(await _service.AddAsync(Mapper.Map<Team>(model)));
        }
    }

    public class TeamInputModel
    {
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Name { get; set; }

        [StringLength(250)]
        public string Description { get; set; }
    }
}

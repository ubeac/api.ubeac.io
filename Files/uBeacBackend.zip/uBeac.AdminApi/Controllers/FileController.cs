﻿using AutoMapper;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.AdminApi.Controllers
{
    using ResultList = ApiResult<IEnumerable<FileUploader>>;
    using Result = ApiResult<FileUploader>;
    public class FileController : BaseController
    {
        protected readonly IMapper Mapper;
        private readonly IHostingEnvironment _hostingEnvironment;
        private IFileService _service;

        public FileController(IMapper mapper, IHostingEnvironment hostingEnvironment, IFileService service)
        {
            Mapper = mapper;
            _hostingEnvironment = hostingEnvironment;
            _service = service;
        }

        [HttpGet]
        public async Task<ApiResult<IEnumerable<FileUploader>>> GetAll()
        {
            var result = await _service.GetAllAsync();
            return ResultList.GetOK(result);
        }

        [HttpDelete]
        public async Task<ApiResult<FileUploader>> Remove(string id)
        {
            var result = await _service.DeleteAsync(id);
            return Result.GetOK();
        }

        [HttpPost]
        public async Task<ResultList> Upload()
        {
            string currentPath = GetFileRoot();
            if (!Directory.Exists(currentPath))
                Directory.CreateDirectory(currentPath);
            var files = HttpContext.Request.Form.Files;

            /*if (!Request.content.IsMimeMultipartContent())
                Ok(New ActionResult(ResultTypes.InvalidFileUploadMime, Nothing, "", New HttpResponseException(HttpStatusCode.UnsupportedMediaType)));*/

            List<FileUploader> savedFiles = new List<FileUploader>();
            if (files.Count == 0)
                return ResultList.GetNOK(ApiCodes.NotFound);

            foreach (var itemFile in files)
            {
                if (itemFile.Length > 0)
                {
                    var addResult = Result.GetOK(await _service.AddAsync(itemFile.FileName, itemFile.Length));
                    if (addResult.Data != null)
                    {
                        string fileGuid = addResult.Data.Id.ToString();
                        using (var stream = new FileStream(currentPath + fileGuid, FileMode.Create))
                        {
                            await itemFile.CopyToAsync(stream);
                        }
                        savedFiles.Add(addResult.Data);
                    }
                }
            }

            return ResultList.GetOK(savedFiles);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            string filePath = GetFileRoot() + id;
            if (!System.IO.File.Exists(filePath))
                return null;

            var entity = _service.GetByIdAsync(id).Result;
            string mime = FileType.GetMimeType(entity.Extension);
            if (mime == "unknown")
            {
                return File(FileStream.Null, "unknown");
                //return ApiResult<FileStreamResult>.GetNOK(ApiCodes.NotFound);
            }
            var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            var result = File(stream, mime, entity.Name + entity.Extension);

            //return ApiResult<FileStreamResult>.GetOK(result);
            return await Task.FromResult(result);
        }

        private string GetFileRoot()
        {
            string path = _hostingEnvironment.ContentRootPath + "\\Files\\";
            return path;
        }
    }


}

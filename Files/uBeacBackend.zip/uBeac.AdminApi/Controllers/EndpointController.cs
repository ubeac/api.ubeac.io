﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;
using uBeacAPI.Config;

namespace uBeac.AdminApi.Controllers
{
    using Result = ApiResult<Endpoint>;
    public class EndPointController : BaseEntityController<Endpoint>
    {
        private IEndpointService _service;
        protected readonly IMapper Mapper;

        public EndPointController(IEndpointService service, IMapper mapper) : base(service)
        {
            _service = service;
            Mapper = mapper;
        }

        [HttpGet]
        // This method returns list of endpoint data with all dependencies like Manufacturer, Gateway and Firmware
        public async Task<ApiResult<IList<EndpointViewModel>>> GetAllWithDependencies()
        {            
            return ApiResult<IList<EndpointViewModel>>.GetOK(await _service.GetAllByDependenciesAsync());
        }

        [HttpGet("id")]
        // This method returns spicific endpoint data with all dependencies like Manufacturer, Gateway and Firmware
        public async Task<ApiResult<EndpointViewModel>> GetWithDependenciesById(string id)
        {
            return ApiResult<EndpointViewModel>.GetOK(await _service.GetWithDependenciesByIdAsync(id));
        }
                
        [HttpGet("{id}")]
        public async Task<ApiResult<IList<Endpoint>>> GetByFirmwareId(string id)
        {
            return ApiResult<IList<Endpoint>>.GetOK(await _service.GetByFirmwareIdAsync(id));
        }

        [HttpPut]
        public async Task<Result> Add([FromBody] EndpointInputModel model)
        {
            Endpoint endPoint = new Endpoint()
            {
                Name = model.Name,
                Url = Helper.RandomString(),
                GatewayFirmwareId = model.GatewayFirmwareId
            };
            return Result.GetOK(await _service.AddAsync(endPoint));
        }

        [HttpPost]
        public async Task<Result> Update([FromBody] EndpointInputModel model)
        {            
            return Result.GetOK(await _service.UpdateAsync(Mapper.Map<Endpoint>(model)));
        }
    }

    public class EndpointInputModel
    {
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Name { get; set; }

        //[RegularExpression(@"^http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?$", ErrorMessage = "url address is not in a correct format. use the structure like http://mysite.com")]
        [Required]
        public string Url { get; set; }

        [Required]
        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Invali Firmware")]
        public string GatewayFirmwareId { get; set; }
    }
        
}

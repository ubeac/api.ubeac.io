﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.AdminApi.Controllers
{
    using Result = ApiResult<Manufacturer>;

    public class ManufacturerController : BaseEntityController<Manufacturer>
    {
        private IManufacturerService _service;

        protected readonly IMapper Mapper;

        public ManufacturerController(IMapper mapper, IManufacturerService service) : base(service)
        {
            _service = service;
            Mapper = mapper;
        }

        [HttpPut]
        public async Task<Result> Add([FromBody] ManufacturerInputModel model)
        {
            return Result.GetOK(await _service.AddAsync(Mapper.Map<Manufacturer>(model)));
        }

        [HttpPost]
        public async Task<Result> Update([FromBody] ManufacturerInputModel model)
        {
            return Result.GetOK(await _service.UpdateAsync(Mapper.Map<Manufacturer>(model)));
        }

        [HttpGet]
        public async Task<ApiResult<IList<ManufacturerViewModel>>> GetHierarchy()
        {
            return ApiResult<IList<ManufacturerViewModel>>.GetOK(await _service.GetHierarchy(true));
        }

    }

    public class ManufacturerInputModel
    {
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Name { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        [RegularExpression(@"^http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?$", ErrorMessage = "website address is not in a correct format. use the structure like http://mysite.com")]
        [Required]
        public string Website { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "logo is not in a correct format")]
        public string Logo { get; set; }
    }

    
}


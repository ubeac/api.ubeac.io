﻿using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;
using AutoMapper;

namespace uBeac.AdminApi.Controllers
{
    using Result = ApiResult<Gateway>;
    public class GatewayController : BaseEntityController<Gateway>
    {
        private IGatewayService _service;
        protected readonly IMapper Mapper;
        public GatewayController(IMapper mapper, IGatewayService service) : base(service)
        {
            Mapper = mapper;
            _service = service;
        }
        [HttpPut]
        public async Task<Result> Add([FromBody] GatewayInputModel model)
        {
            return Result.GetOK(await _service.AddAsync(Mapper.Map<Gateway>(model)));
        }
        [HttpPost]        
        public async Task<Result> Update([FromBody] GatewayInputModel model)
        {
            return Result.GetOK(await _service.UpdateAsync(Mapper.Map<Gateway>(model)));
        }

        [HttpGet("{id}")]
        public async Task<ApiResult<IList<Gateway>>> GetByManufacturerId(string id)
        {
            return ApiResult<IList<Gateway>>.GetOK(await _service.GetByManufacturerIdAsync(id));
        }        
    }

    public class GatewayInputModel
    {
        public string Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Name { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Manual file is not in a correct format")]
        public string ManualFile { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Technical specification is not in a correct format")]
        public string TechnicalSpecFile { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Manufacturer is not valid")]
        public string ManufacturerId { get; set; }
    }
}
﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.AdminApi.Controllers
{
    using Result = ApiResult<GatewayFirmware>;
    public class GatewayFirmwareController : BaseEntityController<GatewayFirmware>
    {
        private IGatewayFirmwareService _service;        
        protected readonly IMapper Mapper;

        public GatewayFirmwareController(IMapper mapper, IGatewayFirmwareService service) : base(service)
        {
            Mapper = mapper;
            _service = service;
        }

        [HttpGet("{id}")]
        public async Task<ApiResult<IList<GatewayFirmware>>> GetByGatewayId(string id)
        {
            return ApiResult<IList<GatewayFirmware>>.GetOK(await _service.GetByGatewayIdAsync(id));            
        }

        [HttpPut]
        public async Task<Result> Add([FromBody] GatewayFirmwareInputModel model)
        {
            return Result.GetOK(await _service.AddAsync(Mapper.Map<GatewayFirmware>(model)));            
        }

        [HttpPost]
        public async Task<Result> Update([FromBody] GatewayFirmwareInputModel model)
        {
            return Result.GetOK(await _service.UpdateAsync(Mapper.Map<GatewayFirmware>(model)));            
        }

        //[HttpGet]
        //public async Task<ApiResult<IList<ManufacturerViewModel>>> GetHierarchy()
        //{
        //    return ApiResult<IList<ManufacturerViewModel>>.GetOK(await _service.GetHierarchyAsync());
        //}
    }

    public class GatewayFirmwareInputModel
    {
        public string Id { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Gateway is not valid")]
        public string GatewayId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string Name { get; set; }

        [StringLength(250)]
        public string Description { get; set; }

        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }

        [RegularExpression(@"^(\{){0,1}[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}(\}){0,1}$", ErrorMessage = "Technical specification is not in a correct format")]
        public string TechnicalSpecFile { get; set; }
    }
}

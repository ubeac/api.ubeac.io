﻿using System;
using System.Linq;

namespace uBeacAPI.Config
{
    public class Helper
    {
        static Random random = new Random();

        public static string RandomString(int length)
        {
            const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";            
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }
        
        public static string RandomString()
        {
            int length = 6;
            return RandomString(length);
        }
                
    }
}

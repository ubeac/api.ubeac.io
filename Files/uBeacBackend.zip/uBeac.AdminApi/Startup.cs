﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using uBeac.Api;

namespace uBeac.AdminApi
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public AppConfig AppConfig;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            AppConfig = new AppConfig();
            configuration.Bind("AppConfig", AppConfig);
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(Configuration);
            services.AddSingleton(AppConfig);
            services.AddScoped<Manager>();
            services.AddCors(AppConfig);

            services
                .AddLog(AppConfig)
                .AddMapper()
                .AddRepositories(Configuration)
                .AddServices()
                .AddApiDocumantation(AppConfig)
                .AddMvcPrepared()
                .AddResponseCompression()
                .AddAuthenticationWithJWT(AppConfig);
            
            services.AddScoped<UserResolverService>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            app
                .UseResponseCompression()
                .UseLog(loggerFactory)
                .UseCors(AppConfig)
                .UseExceptionHandling()
                //.UseAuthenticationWithJWT()
                .UseApiDocumantation(AppConfig)
                .UseMvcPrepared();
        }
    }
}

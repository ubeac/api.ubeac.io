﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using System;
using IdentityModel.Client;
using System.Net.Http;

namespace uBeac.AdminApi.Controllers
{

    public class HomeController : Controller
    {

        //UserManager<User> _userManager;
        //public HomeController(UserManager<User> userManager)
        //{
        //    _userManager = userManager;
        //}

        [HttpGet]
        public IActionResult Index()
        {
            ViewData["Message"] = "Default page.";
            return View();
        }

        [HttpGet]
        [Authorize]
        public IActionResult Secure()
        {
            //var disco =  DiscoveryClient.GetAsync("http://localhost:5000").Result;
            //if (disco.IsError)
            //{
            //    Console.WriteLine(disco.Error);
            //    return null;
            //}

            //// request token
            //var tokenClient = new TokenClient(disco.TokenEndpoint, "AdminApiClient", "secret");
            //var tokenResponse =  tokenClient.RequestClientCredentialsAsync("AdminApi").Result;

            //if (tokenResponse.IsError)
            //{
            //    Console.WriteLine(tokenResponse.Error);
            //    return null;
            //}

            //var x = (tokenResponse.Json);

            //var client = new HttpClient();

            //client.SetBearerToken(tokenResponse.AccessToken);

            //var response = client.GetAsync("http://localhost:5001/identity").Result;
            //if (!response.IsSuccessStatusCode)
            //{
            //    Console.WriteLine(response.StatusCode);
            //}
            //else
            //{
            //    var content = await response.Content.ReadAsStringAsync();
            //    Console.WriteLine(JArray.Parse(content));
            //}


            //var accessToken =  HttpContext.Authentication.GetTokenAsync("access_token").Result;

            //var client = new HttpClient();

            //client.SetBearerToken(accessToken);

            //var userInfoClient = new UserInfoClient("http://localhost:5000/connect/userinfo");

            //var response = await userInfoClient.GetAsync(accessToken);
            //var claims = response.Claims;


            var x = User;
            var y = User.Identity;
            var z = y.Name;
            var c = GetUserId();
            ViewData["Message"] = "Secure page.";
            return View();
        }

        [HttpGet]
        public async Task Logout()
        {
            await HttpContext.SignOutAsync("Cookies");
            await HttpContext.SignOutAsync("oidc");
        }


        public string GetUserId()
        {
            ClaimsPrincipal principal = User;
            if (principal == null)
                throw new ArgumentNullException(nameof(principal));

            return principal.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        }


    }
}
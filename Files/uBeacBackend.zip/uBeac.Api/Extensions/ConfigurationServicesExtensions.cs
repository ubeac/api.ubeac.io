﻿//using AutoMapper;
//using Microsoft.Extensions.Configuration;
//using uBeac.AdminApi.Controllers;
//using uBeac.Models;
//using uBeac.Repositories;
//using uBeac.Services;
//using uBeacAPI.Repositories;

//namespace Microsoft.Extensions.DependencyInjection
//{
//    public static class ConfigurationServicesExtensions
//    {

//        public static IServiceCollection AddRepositories(this IServiceCollection services, IConfiguration configuration)
//        {

//            services.AddDatabase(configuration);

//            //services.AddScoped<IManufacturerRepository, ManufacturerRepository>();
//            //services.AddScoped<IGatewayRepository, GatewayRepository>();
//            //services.AddScoped<IGatewayFirmwareRepository, GatewayFirmwareRepository>();
//            //services.AddScoped<ITeamRepository, TeamRepository>();
//            //services.AddScoped<IFileRepository, FileRepository>();
//            //services.AddScoped<IEndpointRepository, EndpointRepository>();
//            return services;
//        }
        
//        public static IServiceCollection AddServices(this IServiceCollection services)
//        {
//            //services.AddScoped<IManufacturerService, ManufacturerService>();
//            //services.AddScoped<IGatewayService, GatewayService>();
//            //services.AddScoped<IGatewayFirmwareService, GatewayFirmwareService>();
//            //services.AddScoped<ITeamService, TeamService>();
//            //services.AddScoped<IFileService, FileService>();
//            //services.AddScoped<IEndpointService, EndpointService>();
//            return services;
//        }

//        public static IServiceCollection AddMapper(this IServiceCollection services)
//        {
//            services.AddAutoMapper(cfg =>
//            {
//                //cfg.CreateMap<ManufacturerInputModel, Manufacturer>();
//                //cfg.CreateMap<GatewayInputModel, Gateway>();
//                //cfg.CreateMap<GatewayFirmwareInputModel, GatewayFirmware>();
//                //cfg.CreateMap<TeamInputModel, Team>();
//                //cfg.CreateMap<EndpointInputModel, Endpoint>();
//            });

//            return services;
//        }

//    }

//}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.Api.Controllers
{
    
    [Produces("application/json")]
    [Route("api/Manufacturer")]
    public class ManufacturerController : BaseEntityController<Manufacturer>
    {
        private IManufacturerService _service;

        public ManufacturerController(IManufacturerService service) : base(service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ApiResult<IList<ManufacturerViewModel>>> GetHierarchy()
        {
            return ApiResult<IList<ManufacturerViewModel>>.GetOK(await _service.GetHierarchy(true));
        }
    }
}
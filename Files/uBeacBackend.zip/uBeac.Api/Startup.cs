﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace uBeac.Api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public AppConfig AppConfig;

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            AppConfig = new AppConfig();
            configuration.Bind("AppConfig", AppConfig);
        }       

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(Configuration);
            services.AddSingleton(AppConfig);
            services.AddScoped<Manager>();
            services.AddCors(AppConfig);

            services
                .AddLog(AppConfig)
                .AddMapper()
                .AddRepositories(Configuration)
                .AddServices()
                .AddApiDocumantation(AppConfig)
                .AddMvcPrepared()
                .AddResponseCompression()
                .AddAuthenticationWithJWT(AppConfig);
            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app
                .UseResponseCompression()
                //.UseLog(loggerFactory)
                .UseCors(AppConfig)
                .UseExceptionHandling()
                //.UseAuthenticationWithJWT()
                .UseApiDocumantation(AppConfig)
                .UseMvcPrepared();

            app.UseMvc();
        }
    }
}

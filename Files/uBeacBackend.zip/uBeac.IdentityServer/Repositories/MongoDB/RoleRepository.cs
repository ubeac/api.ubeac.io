﻿using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories.MongoDB
{
    public class RoleRepository<TRole> :
        MongoGenericRepository<TRole>,
        IRoleRepository<TRole>
        where TRole : Role
    {

        public RoleRepository(IMongoDatabase database) : base(database)
        {
        }

        protected override string CollectionName { get => "Roles"; }

        protected override async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            var pack = ConventionRegistry.Lookup(typeof(CamelCaseElementNameConvention));

            var roleNameKeyBuilder = Builders<TRole>.IndexKeys.Ascending(role => role.Name);

            var tasks = new[]
            {
                Collection.Indexes.CreateOneAsync(roleNameKeyBuilder, new CreateIndexOptions { Unique = true, Name ="IDX_RoleName" })
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);

        }

        public async Task<TRole> GetByNameAsync(string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TRole>.Filter.Eq(x => x.NormalizedName, name);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);


            return result.FirstOrDefault();
        }

        public IQueryable<TRole> AsQueryableAsync()
        {
            return Collection.AsQueryable();
        }

        protected override string GetIdValue(TRole entity) => entity.Id;

        protected override void SetIdValue(TRole entity)
        {
            //nothing   
        }
    }
}

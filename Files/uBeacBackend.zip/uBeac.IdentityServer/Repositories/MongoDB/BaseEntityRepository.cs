﻿//using MongoDB.Driver;
//using System;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.MongoDB
//{
//    public abstract class BaseEntityRepository<TEntity> : MongoGenericRepository<TEntity> where TEntity : BaseEntity
//    {
//        public BaseEntityRepository(IMongoDatabase database) : base(database)
//        {
//        }

//        protected override string GetIdValue(TEntity entity) =>
//            entity.Id;

//        protected override void SetIdValue(TEntity entity) =>
//            entity.Id = Guid.NewGuid().ToString();

//    }
//}

﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories
{
    public interface IUserRepository<TUser> :
        IRepository<TUser>
        where TUser : User
    {
        Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken = default(CancellationToken));
        Task<TUser> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<TUser>> GetUsersForClaimAsync(string claimType, string claimValue, CancellationToken cancellationToken = default(CancellationToken));
        Task<TUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<TUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken = default(CancellationToken));
    }
}

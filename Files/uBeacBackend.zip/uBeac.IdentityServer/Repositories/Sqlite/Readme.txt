﻿To install the database:

1- Set the proper connection string in appsettings.json
 "ConnectionStrings": {
     "DefaultConnection": "Data Source=C:\\Users\\a.pournasserian\\Desktop\\uBeac.Auth\\uBeac.Auth.IdentityServer\\DB\\IdentityDB.sqlite"
  }

2- Run These command in Package Manager Console:
Add-Migration InitialDBSchema -Project uBeac.IdentityServer
Update-Database
﻿//using Microsoft.AspNetCore.Identity;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.Sqlite
//{
//    public static class SqliteIdentityBuilderExtensions
//    {
//        public static IdentityBuilder AddIdentityWithSqliteStores<TUser, TRole>(this IServiceCollection services, string connectionString) where TUser : User where TRole : Role
//        {

//            // SQLite & Identity.
//            services.AddDbContext<ApplicationDbContext<TUser, TRole>>(options =>
//                options.UseSqlite(connectionString, x => x.MigrationsAssembly("uBeac.IdentityServer")));

//            return services.AddIdentity<TUser, IdentityRole>()
//                  .AddEntityFrameworkStores<ApplicationDbContext<TUser, TRole>>()
//                  .AddDefaultTokenProviders();

//        }
//    }
//}

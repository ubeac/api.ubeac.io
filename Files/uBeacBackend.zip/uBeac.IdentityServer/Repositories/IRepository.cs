﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace uBeac.IdentityServer.Repositories
{
    public interface IRepository<TEntity> :
        IDisposable
        where TEntity : class
    {
        Task<TEntity> InsertAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> UpdateAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken));
        IQueryable<TEntity> AsQueryableAsync(CancellationToken cancellationToken = default(CancellationToken));
    }
}

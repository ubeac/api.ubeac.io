﻿//using Microsoft.AspNetCore.Identity;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.DependencyInjection;
//using System;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.EF
//{
//    public static class EFIdentityBuilderExtensions
//    {
//        public static IdentityBuilder AddIdentityWithEFStores<TUser, TRole>(this IServiceCollection services, string connectionString, Action<IdentityOptions> setupAction) where TUser : User where TRole : Role
//        {
//            services.AddDbContext<ApplicationDbContext<TUser,TRole>>
//                (options => options.UseSqlServer(
//                    connectionString, x => x.MigrationsAssembly("uBeac.IdentityServer")));

//            return services.AddIdentity<TUser, TRole>(setupAction)
//                 .AddEntityFrameworkStores<ApplicationDbContext<TUser,TRole>>()
//                 .AddDefaultTokenProviders();

//        }
//    }
//}

﻿//using Microsoft.AspNetCore.Identity;
//using System;
//using System.Collections.Generic;
//using System.Security.Claims;
//using System.Text;
//using System.Threading.Tasks;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.EF
//{
//    public class DbInitializer : IDbInitializer
//    {
//        private readonly UserManager<User> _userManager;
//        private readonly RoleManager<Role> _roleManager;

//        public DbInitializer(UserManager<User> userManager, RoleManager<Role> roleManager)
//        {
//            _userManager = userManager;
//            _roleManager = roleManager;
//        }

//        public async Task Initialize(ApplicationDbContext context)
//        {
//            context.Database.EnsureCreated();

//            if (context.Users.Any())
//            {
//                return;
//            }

//            // Creates Roles.
//            await _roleManager.CreateAsync(new IdentityRole("administrator"));
//            await _roleManager.CreateAsync(new IdentityRole("user"));

//            // Seeds an admin user.
//            var user = new User
//            {
//                GivenName = "Admin",
//                FamilyName = "Admin",
//                AccessFailedCount = 0,
//                Email = "admin@gmail.com",
//                EmailConfirmed = false,
//                LockoutEnabled = true,
//                NormalizedEmail = "ADMIN@GMAIL.COM",
//                NormalizedUserName = "ADMIN@GMAIL.COM",
//                TwoFactorEnabled = false,
//                UserName = "admin@gmail.com"
//            };

//            var result = await _userManager.CreateAsync(user, "Admin01*");

//            if (result.Succeeded)
//            {
//                var adminUser = await _userManager.FindByNameAsync(user.UserName);
//                // Assigns the administrator role.
//                await _userManager.AddToRoleAsync(adminUser, "administrator");
//                // Assigns claims.
//                var claims = new List<Claim> {
//                    new Claim(type: JwtClaimTypes.GivenName, value: user.GivenName),
//                    new Claim(type: JwtClaimTypes.FamilyName, value: user.FamilyName),
//                };
//                await _userManager.AddClaimsAsync(adminUser, claims);
//            }
//        }
//    }
//}

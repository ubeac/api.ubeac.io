﻿//using Microsoft.AspNetCore.Identity;
//using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
//using Microsoft.EntityFrameworkCore;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.EF
//{
//    public class ApplicationDbContext<TUser, TRole> :
//        IdentityDbContext<TUser, TRole, string>
//        where TUser : User
//        where TRole : Role
//    {
//        public ApplicationDbContext(DbContextOptions<ApplicationDbContext<TUser, TRole>> options) : base(options)
//        {
//        }

//        protected override void OnModelCreating(ModelBuilder builder)
//        {
//            base.OnModelCreating(builder);
//            //builder.Entity<IdentityUser>().ToTable("Users").Property(p => p.Id).HasColumnName("UserId");
//            //builder.Entity<TUser>().ToTable("Users").Property(p => p.Id).HasColumnName("UserId");
//            //builder.Entity<TRole>().ToTable("Roles").Property(p => p.Id).HasColumnName("RoleId");
//            //builder.Entity<UserRole>().ToTable("UserRoles").Property(p => p.RoleId).HasColumnName("RoleId"); ;
//            //builder.Entity<UserLogin>().ToTable("UserLogins");
//            //builder.Entity<UserClaim>().ToTable("UserClaims");
//            //builder.Entity<RoleClaim>().ToTable("RoleClaims");
//            //builder.Entity<UserToken>().ToTable("UserTokens");
//            //builder.Entity<Profile>().ToTable("Profiles").HasKey("Username");
//        }

//    }
    
//    //public class ApplicationDbContext<TUser, TRole, TUserClaim, TUserRole, TUserLogin, TRoleClaim, TUserToken> :
//    //    IdentityDbContext<TUser, TRole, string, TUserClaim, TUserRole, TUserLogin, TRoleClaim, TUserToken>
//    //    where TUser : User
//    //    where TRole : Role
//    //    where TUserClaim : UserClaim
//    //    where TUserRole : UserRole
//    //    where TUserLogin : UserLogin
//    //    where TRoleClaim : RoleClaim
//    //    where TUserToken : UserToken
//    //{
//    //    public ApplicationDbContext(DbContextOptions<ApplicationDbContext<TUser, TRole, TUserClaim, TUserRole, TUserLogin, TRoleClaim, TUserToken>> options) : base(options)
//    //    {
//    //    }

//    //    protected override void OnModelCreating(ModelBuilder builder)
//    //    {
//    //        base.OnModelCreating(builder);
//    //        builder.Entity<IdentityUser>().ToTable("Users").Property(p => p.Id).HasColumnName("UserId");
//    //        builder.Entity<TUser>().ToTable("Users").Property(p => p.Id).HasColumnName("UserId");
//    //        builder.Entity<TRole>().ToTable("Roles").Property(p => p.Id).HasColumnName("RoleId");
//    //        builder.Entity<TUserRole>().ToTable("UserRoles").Property(p => p.RoleId).HasColumnName("RoleId"); ;
//    //        builder.Entity<TUserLogin>().ToTable("UserLogins");
//    //        builder.Entity<TUserClaim>().ToTable("UserClaims");
//    //        builder.Entity<TRoleClaim>().ToTable("RoleClaims");
//    //        builder.Entity<TUserToken>().ToTable("UserTokens");
//    //        builder.Entity<Profile>().ToTable("Profiles").HasKey("Username");
//    //    }
//    //}
//}

﻿//using System.Threading.Tasks;
//using uBeac.IdentityServer.Models;

//namespace uBeac.IdentityServer.Repositories.EF
//{
//    public interface IDbInitializer
//    {
//        Task Initialize(ApplicationDbContext<User, Role> context);
//    }
//}

﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories
{
    public interface IRoleRepository<TRole> :
        IRepository<TRole>
        where TRole : Role
    {
        IQueryable<TRole> AsQueryableAsync();
        Task<TRole> GetByNameAsync(string name, CancellationToken cancellationToken = default(CancellationToken));

    }
}

﻿using System.Threading.Tasks;

namespace uBeac.IdentityServer.Services
{
    public interface IEmailSender
    {
        Task SendEmailAsync(string email, string subject, string message);
    }
}

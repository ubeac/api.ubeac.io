﻿using IdentityServer4.Models;
using System.Collections.Generic;
using static IdentityServer4.IdentityServerConstants;

namespace uBeac.IdentityServer
{
    public class Config
    {

        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                new IdentityResources.Email(),
                new IdentityResources.Phone(),
                new IdentityResources.Address(),
                new IdentityResource("Roles","Roles for the user", new List<string> { "role" })
            };
        }

        //public static IEnumerable<ApiResource> GetApiResources()
        //{
        //    return new List<ApiResource>
        //    {
        //        new ApiResource("IdentityServer" ) {
        //            UserClaims = {
        //                //StandardScopes.OpenId,
        //                //StandardScopes.Profile,
        //                //StandardScopes.Phone,
        //                //StandardScopes.Email,
        //                //StandardScopes.Address,
        //                //"role"
        //            }
        //        },
        //        new ApiResource("AdminApi" ) {
        //            UserClaims = {
        //                StandardScopes.OpenId,
        //                //StandardScopes.Profile,
        //                //StandardScopes.Phone,
        //                //StandardScopes.Email,
        //                //StandardScopes.Address,
        //                //"role"
        //            }
        //        },
        //        new ApiResource("Api" ) {
        //            UserClaims = {
        //                StandardScopes.OpenId,
        //                //StandardScopes.Profile,
        //                //StandardScopes.Phone,
        //                //StandardScopes.Email,
        //                //StandardScopes.Address,
        //                //"role"
        //            }
        //        }
        //    };
        //}

        //public static IEnumerable<Client> GetClients()
        //{
        //    return new List<Client>
        //    {
        //        new Client
        //        {
        //            ClientId = "AdminUIClient",
        //            ClientName = "uBeac Admin UI Client",
        //            AllowedGrantTypes = GrantTypes.Implicit,
        //            AllowAccessTokensViaBrowser = true,
        //            RequireConsent = false,
        //            RedirectUris = { "http://localhost:55712/callback.html", "http://admin.ubeac.io/callback.html" },
        //            PostLogoutRedirectUris = { "http://localhost:55712/index.html",  "http://admin.ubeac.io/index.html" },
        //            AllowedCorsOrigins={ "http://localhost:55712", "http://admin.ubeac.io"  },
        //            AllowedScopes =
        //            {
        //                StandardScopes.OpenId,
        //                StandardScopes.Profile,
        //                StandardScopes.Phone,
        //                StandardScopes.Email,
        //                StandardScopes.Address,
        //                "IdentityServer",
        //                "AdminApi",
        //                "Api",
        //                "Roles"
        //            }
        //        },
        //        new Client
        //        {
        //            ClientId = "AdminApiClient",
        //            ClientName = "uBeac Admin Api Client",
        //            AllowedGrantTypes = GrantTypes.ClientCredentials,
        //             AllowedCorsOrigins={ "http://localhost:61798", "http://adminapi.ubeac.io"  },
        //            AllowedScopes =
        //            {
        //                StandardScopes.OpenId,
        //                StandardScopes.Profile,
        //                StandardScopes.Phone,
        //                StandardScopes.Email,
        //                StandardScopes.Address,
        //                "AdminApi",
        //                "Roles"
        //            }
        //        },
        //        new Client
        //        {
        //            ClientId = "AdminApiSwaggerClient",
        //            ClientName = "uBeac Admin Api Swagger Client",
        //            ClientSecrets = {new Secret("secret".Sha256()) },
        //            AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
        //            AllowAccessTokensViaBrowser = true,
        //            RequireConsent = false,
        //            RedirectUris = { "http://localhost:61798/signin-oidc", "http://adminapi.ubeac.io/signin-oidc" },
        //            PostLogoutRedirectUris = { "http://localhost:61798/signout-callback-oidc",  "http://adminapi.ubeac.io/signout-callback-oidc" },
        //            AllowedCorsOrigins={ "http://localhost:61798", "http://adminapi.ubeac.io"  },
        //            AllowedScopes =
        //            {
        //                StandardScopes.OpenId,
        //                StandardScopes.Profile,
        //                StandardScopes.Phone,
        //                StandardScopes.Email,
        //                StandardScopes.Address,
        //                "AdminApi",
        //                "Roles"
        //            }
        //        }
        //    };

        //}

    }

}

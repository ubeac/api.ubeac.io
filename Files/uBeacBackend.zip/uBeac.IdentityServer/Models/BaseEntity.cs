﻿//using System;

//namespace uBeac.IdentityServer.Models
//{
//    public class BaseEntity
//    {
//        public string Id { get; set; }
//        public DateTime CreationDate { get; set; }
//        public DateTime UpdateDate { get; set; }
//        public string CreateBy { get; set; }
//        public string UpdateBy { get; set; }
//    }
//}

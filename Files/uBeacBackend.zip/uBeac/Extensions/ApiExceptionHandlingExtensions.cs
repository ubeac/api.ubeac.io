﻿using Microsoft.AspNetCore.Builder;
using uBeac.Api;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ApiExceptionHandlingExtensions
    {
        public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder app)
        {
            return app.UseMiddleware(typeof(ExceptionHandlingMiddleware));
        }
    }
}

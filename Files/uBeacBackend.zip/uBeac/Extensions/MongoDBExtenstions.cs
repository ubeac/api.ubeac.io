﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class MongoDBExtenstions
    {
        public static IServiceCollection AddDatabase(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDatabase(configuration, "DefaultConnection");
            return services;
        }

        public static IServiceCollection AddDatabase(this IServiceCollection services, IConfiguration configuration, string connectionName )
        {
            // defining MongoClient
            services.AddSingleton(provider =>
            {
                var mongoUrl = new MongoUrl(configuration.GetConnectionString(connectionName));
                var client = new MongoClient(mongoUrl);
                return client.GetDatabase(mongoUrl.DatabaseName);
            });

            return services;
        }
        
    }
}

﻿using IdentityModel;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.IdentityModel.Tokens;
using uBeac;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class AuthenticationExtensions
    {

        public static IServiceCollection AddAuthenticationWithJWT(this IServiceCollection services, AppConfig AppConfig)
        {

            foreach (var client in AppConfig.IdentityServerClients)
            {
                switch (client.AuthenticationScheme)
                {
                    case JwtBearerDefaults.AuthenticationScheme:

                        client.Authority.ThrowIfNull();
                        client.ApiName.ThrowIfNull();

                        services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                            .AddIdentityServerAuthentication(options =>
                            {
                                options.Authority = client.Authority;
                                options.RequireHttpsMetadata = false;
                                options.ApiName = client.ApiName;
                            });
                        break;


                    case CookieAuthenticationDefaults.AuthenticationScheme:

                        client.Authority.ThrowIfNull();
                        client.ClientId.ThrowIfNull();
                        client.ClientSecret.ThrowIfNull();
                        client.ResponseType.ThrowIfNull();
                        client.Scopes.ThrowIfNull();

                        services.AddAuthentication()
                            .AddCookie(authenticationScheme: CookieAuthenticationDefaults.AuthenticationScheme)
                            .AddOpenIdConnect("oidc", options =>
                            {
                                options.SignInScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                                options.Authority = client.Authority;
                                options.RequireHttpsMetadata = false;
                                options.ClientId = client.ClientId;
                                options.ClientSecret = client.ClientSecret;
                                options.SaveTokens = true;
                                options.ResponseType = client.ResponseType;
                                foreach (string scopeName in client.Scopes.Split(" "))
                                {
                                    options.Scope.Add(scopeName);
                                }
                                options.ClaimActions.Remove("amr");
                                options.SaveTokens = true;
                                options.GetClaimsFromUserInfoEndpoint = true;
                                options.TokenValidationParameters = new TokenValidationParameters
                                {
                                    NameClaimType = JwtClaimTypes.Name,
                                    RoleClaimType = JwtClaimTypes.Role
                                };
                            });                       

                        break;
                }
            }

            services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = "oidc";
            });

            return services;
        }

        public static IApplicationBuilder UseAuthenticationWithJWT(this IApplicationBuilder app)
        {
            app.UseAuthentication();

            app.Use(async (context, next) =>
            {
                if (!context.User.Identity.IsAuthenticated)
                {
                    var result = await context.AuthenticateAsync(JwtBearerDefaults.AuthenticationScheme);
                    if (result?.Principal != null)
                    {
                        context.User = result.Principal;
                    }
                }

                await next.Invoke();
            });

            return app;
        }
        
    }
}

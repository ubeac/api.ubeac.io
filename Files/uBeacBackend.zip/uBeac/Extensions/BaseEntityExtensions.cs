﻿using System;
using uBeac.Models;

namespace uBeac
{
    public static class BaseEntityExtensions
    {
        //todo: correct current user
        public static void PrepareForInsert(this BaseEntity entity)
        {
            DateTime currentDate = DateTime.UtcNow;
            entity.CreationDate = currentDate;
            entity.UpdateDate = currentDate;
            entity.CreateBy = "Amir1";
            entity.UpdateBy = "Amir1";
        }

        public static void PrepareForUpdate(this BaseEntity entity)
        {
            DateTime currentDate = DateTime.UtcNow;
            entity.UpdateDate = currentDate;
            entity.UpdateBy = "Amir2";
        }
        
    }
}

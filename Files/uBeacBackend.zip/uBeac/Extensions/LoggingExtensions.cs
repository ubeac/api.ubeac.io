﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Sinks.RollingFileAlternative;
using uBeac;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class LoggingExtensions
    {
        public static IServiceCollection AddLog(this IServiceCollection services, AppConfig appConfig)
        {
            string logFilePath = ".\\logs\\log-{Date}.txt";
            if (!string.IsNullOrEmpty(appConfig.LogFilePath))
            {
                logFilePath = appConfig.LogFilePath;
            }

            Log.Logger = new LoggerConfiguration().MinimumLevel.Debug().WriteTo.RollingFile(logFilePath).CreateLogger();
            return services;
        }

        public static IApplicationBuilder UseLog(this IApplicationBuilder app, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddSerilog();
            return app;
        }
    }
      
}

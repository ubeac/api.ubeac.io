﻿using Microsoft.AspNetCore.Builder;
using uBeac;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class CorsExtensions
    {
        public const string CorsName = "AppConfigCors";

        public static IServiceCollection AddCors(this IServiceCollection services, AppConfig appConfig)
        {
            if (appConfig.CorsOrigins is null) return services;

            services.AddCors(options =>
            {
                options.AddPolicy(CorsName, policy =>
                {
                    foreach (string item in appConfig.CorsOrigins)
                    {
                        policy.WithOrigins(item).SetIsOriginAllowedToAllowWildcardSubdomains().AllowAnyHeader().AllowAnyMethod();
                    }
                });
            });

            return services;
        }

        public static IApplicationBuilder UseCors(this IApplicationBuilder app, AppConfig appConfig)
        {
            if (appConfig.CorsOrigins != null)
            {
                app.UseCors(CorsName);
            }
            return app;
        }

    }
}

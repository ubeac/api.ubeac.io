﻿using Microsoft.AspNetCore.Builder;
using uBeac.Api;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class MvcExtensions
    {

        public static IServiceCollection AddMvcPrepared(this IServiceCollection services)
        {
            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ModelStateValidationAsyncActionFilter));
            });
            return services;
        }

        public static IApplicationBuilder UseMvcPrepared(this IApplicationBuilder app)
        {
            app.UseStaticFiles();
            app.UseMvcWithDefaultRoute();
            return app;
        }

    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace uBeac.Api
{
    public class ModelStateValidationAsyncActionFilter : IAsyncActionFilter
    {
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var req = context.HttpContext.Request.Path;

            if (context.ModelState.IsValid)
            {
                var resultContext = await next();
            }
            else
            {
                var validationErrors = new List<KeyValuePair<string, string>>();
                foreach (string key in context.ModelState.Keys)
                {
                    foreach (var error in context.ModelState[key].Errors)
                    {
                        validationErrors.Add(new KeyValuePair<string, string>(key, error.ErrorMessage));
                    }
                }

                var result = ApiResult.GetNOK(ApiCodes.BadRequest, "Bad Request", validationErrors);
                
                context.Result = new BadRequestObjectResult(result);
            }
        }
    }
}

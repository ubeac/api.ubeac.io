﻿using System;

namespace uBeac.Api
{
    public class ApiResult<TResult>
        where TResult : class
    {
        public ApiCodes Code { get; set; }
        public string Description { get; set; }
        public TResult Data { get; set; }
        public object Errors { get; set; }

        public static ApiResult<TResult> GetNOK(Exception ex)
        {
            return GetNOK(ApiCodes.UnhandledException, ex.Message, ex);
        }

        public static ApiResult<TResult> GetNOK(ApiCodes code)
        {
            return GetNOK(code, string.Empty);
        }

        public static ApiResult<TResult> GetNOK(ApiCodes code, string description)
        {
            return GetNOK(code, description, null);
        }

        public static ApiResult<TResult> GetNOK(ApiCodes code, string description, object errors)
        {
            return new ApiResult<TResult> { Code = code, Description = description, Data = null, Errors = errors };
        }

        public static ApiResult<TResult> GetOK()
        {
            return GetOK(null, string.Empty);
        }

        public static ApiResult<TResult> GetOK(TResult data)
        {
            return GetOK(data, string.Empty);
        }

        public static ApiResult<TResult> GetOK(TResult data, string description)
        {
            return new ApiResult<TResult> { Code = ApiCodes.OK, Description = description, Data = data };
        }

        public static ApiResult<TResult> GetResult(TResult data)
        {
            if (data is null)
            {
                return GetNOK(ApiCodes.UnhandledException);

            }
            else
            {
                return GetOK(data);
            }

        }

    }

    public class ApiResult : ApiResult<object>
    {
    }
    
}

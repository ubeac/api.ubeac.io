﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace uBeac.Api
{
    public class UserResolverService
    {
        private readonly IHttpContextAccessor _context;
        public UserResolverService(IHttpContextAccessor context)
        {
            _context = context;
        }

        public string GetUserId()
        {
            if (_context.HttpContext.User.Identity.IsAuthenticated)
            {
                string userid = _context.HttpContext.User?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                if (string.IsNullOrEmpty(userid))
                {
                    userid = _context.HttpContext.User?.FindFirst("sub")?.Value;
                }
                return userid;
            }
            else
            {
                return string.Empty;
            }
        }

        public string GetUsername()
        {
            if (_context.HttpContext.User.Identity.IsAuthenticated)
            {
                return _context.HttpContext.User?.Identity?.Name;
            }
            else
            {
                return string.Empty;
            }
        }
    }
}

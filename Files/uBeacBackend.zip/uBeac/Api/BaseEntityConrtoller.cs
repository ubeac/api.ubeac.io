﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Services;

namespace uBeac.Api
{
    public abstract class BaseEntityController<TEntity> : BaseController
        where TEntity : BaseEntity
    {
        IBaseEntityService<TEntity> Service;
        public BaseEntityController(IBaseEntityService<TEntity> service)
        {
            service.ThrowIfNull();
            Service = service;
        }

        [HttpGet("{id}")]
        public virtual async Task<ApiResult<TEntity>> GetById(string id)
        {
            var result = await Service.GetByIdAsync(id);
            return ApiResult<TEntity>.GetOK(result);
        }

        [HttpGet]
        public virtual async Task<ApiResult<IEnumerable<TEntity>>> GetAll()
        {
            var result = await Service.GetAllAsync();
            return ApiResult<IEnumerable<TEntity>>.GetOK(result);
        }

        [HttpDelete]
        public virtual async Task<ApiResult<TEntity>> Remove(string id)
        {
            var result = await Service.DeleteAsync(id);
            return ApiResult<TEntity>.GetOK();
        }
        
    }
}
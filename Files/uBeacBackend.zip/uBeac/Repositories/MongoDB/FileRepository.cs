﻿using MongoDB.Driver;
using System;
using uBeac.Models;
using uBeac.Repositories;
using uBeac.Repositories.MongoDB;

namespace uBeacAPI.Repositories
{
    public class FileRepository : MongoGenericRepository<FileUploader>, IFileRepository
    {
        public FileRepository(IMongoDatabase database) : base(database)
        {
        }

        protected override string GetIdValue(FileUploader entity) => entity.Id;

        protected override void SetIdValue(FileUploader entity) => entity.Id = Guid.NewGuid().ToString();

        protected override string CollectionName { get => "Files"; }        
                
    }

    public interface IFileRepository : IDisposable, IRepository<FileUploader>
    {
    }
}
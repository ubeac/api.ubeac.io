﻿using MongoDB.Driver;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson.Serialization.Conventions;
using System.Threading;
using System.Collections.Generic;
using uBeac.Repositories.MongoDB;
using uBeac.Models;
using uBeac;
using uBeac.Repositories;

namespace uBeacAPI.Repositories
{
    public class GatewayFirmwareRepository : BaseEntityRepository<GatewayFirmware>, IGatewayFirmwareRepository
    {
        private readonly IGatewayRepository _gatewayRepository;
        private readonly IManufacturerRepository _manufacturerRepository;
        public GatewayFirmwareRepository(IMongoDatabase database, IGatewayRepository gatewayRepository, IManufacturerRepository manufacturerRepository) : base(database)
        {
            _gatewayRepository = gatewayRepository;
            _manufacturerRepository = manufacturerRepository;
        }
        protected override string CollectionName { get => "GatewayFirmwares"; }
        protected override string GetIdValue(GatewayFirmware entity) => entity.Id;

        public bool DoesGatewayExist(string gatewayId, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            gatewayId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return (_gatewayRepository.GetByIdAsync(gatewayId).Result != null);
        }

        public bool DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            var query = Builders<GatewayFirmware>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"));
            cancellationToken.ThrowIfCancellationRequested();

            return (Collection.Find(query).FirstOrDefault() != null);
        }

        public bool DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();

            var query = Builders<GatewayFirmware>.Filter.And(
                Builders<GatewayFirmware>.Filter.Not(Builders<GatewayFirmware>.Filter.Eq(m => m.Id, id)),
                Builders<GatewayFirmware>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"))
                );
            cancellationToken.ThrowIfCancellationRequested();

            return (Collection.Find(query).FirstOrDefault() != null);
        }

        protected override async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            var pack = ConventionRegistry.Lookup(typeof(CamelCaseElementNameConvention));

            var nameKeyBuilder = Builders<GatewayFirmware>.IndexKeys.Ascending(firmWare => firmWare.Name);

            var tasks = new[]
            {
                Collection.Indexes.CreateOneAsync(nameKeyBuilder, new CreateIndexOptions { Unique = true, Name ="IDX_FirmwareName" })
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);

        }

        public async Task<IList<GatewayFirmware>> GetByGatewayIdAsync(string gatewayId, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            gatewayId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
            FilterDefinition<GatewayFirmware> query = Builders<GatewayFirmware>.Filter.Eq(x => x.GatewayId, gatewayId);

            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.ToList();
        }

        //public async Task<IList<ManufacturerViewModel>> GetHierarchyAsync(CancellationToken cancellationToken = default(CancellationToken))
        //{
        //    IList<ManufacturerViewModel> ManufacturersList = new List<ManufacturerViewModel>();

        //    var manufacturerList = await _manufacturerRepository.GetAllAsync();
        //    foreach (Manufacturer manufacturer in manufacturerList)
        //    {
        //        if (manufacturer.Id != null)
        //        {
        //            List<GatewayViewModel> GatewaysList = new List<GatewayViewModel>();
        //            var gatewayList = await _gatewayRepository.GetByManufacturerIdAsync(manufacturer.Id);

        //            foreach (Gateway gateway in gatewayList)
        //            {
        //                var firmwareList = await GetByGatewayIdAsync(gateway.Id);
        //                GatewayViewModel Gateways = new GatewayViewModel()
        //                {
        //                    Gateway = gateway,
        //                    Firmwares = firmwareList
        //                };
        //                GatewaysList.Add(Gateways);
        //            }

        //            ManufacturerViewModel Manufacturers = new ManufacturerViewModel()
        //            {
        //                Manufacturer = manufacturer,
        //                Gateways = GatewaysList
        //            };
        //            ManufacturersList.Add(Manufacturers);
        //        }
        //    }

        //    return ManufacturersList;

        //}
    }
}
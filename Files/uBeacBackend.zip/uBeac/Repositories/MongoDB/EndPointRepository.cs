﻿using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Repositories.MongoDB;
using uBeac;
using uBeac.Repositories;

namespace uBeacAPI.Repositories
{
    public class EndpointRepository : BaseEntityRepository<Endpoint>, IEndpointRepository
    {
        private readonly IManufacturerRepository _manufacturerRepository;
        private readonly IGatewayRepository _gatewayRepository;
        private readonly IGatewayFirmwareRepository _firmwareRepository;

        protected override string CollectionName { get => "EndPoint"; }

        public EndpointRepository(IMongoDatabase database, IManufacturerRepository manufacturerRepository, IGatewayRepository gatewayRepository, IGatewayFirmwareRepository gatewayFirmwareRepository) : base(database)
        {
            _manufacturerRepository = manufacturerRepository;
            _gatewayRepository = gatewayRepository;
            _firmwareRepository = gatewayFirmwareRepository;
        }

        public async Task<bool> DoesUrlExist(string url, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            url.ThrowIfNull();
            var query = Builders<Endpoint>.Filter.Regex(ep => ep.Url, new MongoDB.Bson.BsonRegularExpression("/^" + url + "$/i"));
            cancellationToken.ThrowIfCancellationRequested();

            return await Task.FromResult(Collection.Find(query).FirstOrDefault() != null);
        }

        public async Task<bool> DoesUrlExist(string id, string url, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            url.ThrowIfNull();
            var query = Builders<Endpoint>.Filter.And(
                Builders<Endpoint>.Filter.Not(Builders<Endpoint>.Filter.Eq(m => m.Id, id)),
                Builders<Endpoint>.Filter.Regex(m => m.Url, new MongoDB.Bson.BsonRegularExpression("/^" + url + "$/i"))
                );
            cancellationToken.ThrowIfCancellationRequested();

            return await Task.FromResult(Collection.Find(query).FirstOrDefault() != null);
        }

        public async Task<Endpoint> GetByUrlAsync(string url, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            url.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
            FilterDefinition<Endpoint> query = Builders<Endpoint>.Filter.Eq(x => x.Url, url);

            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        protected override async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            var pack = ConventionRegistry.Lookup(typeof(CamelCaseElementNameConvention));

            var nameKeyBuilder = Builders<Endpoint>.IndexKeys.Ascending(endpoint => endpoint.Url);

            var tasks = new[]
            {
                Collection.Indexes.CreateOneAsync(nameKeyBuilder, new CreateIndexOptions { Unique = true, Name ="IDX_EndPointUrl" })
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);
        }

        public async Task<IList<Endpoint>> GetByFirmwareIdAsync(string firmwareId, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            firmwareId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
            FilterDefinition<Endpoint> query = Builders<Endpoint>.Filter.Eq(x => x.GatewayFirmwareId, firmwareId);

            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.ToList();
        }

        public async Task<IList<EndpointViewModel>> GetAllByDependenciesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            var query = from endpoint in AsQueryableAsync()
                        join firmware in _firmwareRepository.AsQueryableAsync() on endpoint.GatewayFirmwareId equals firmware.Id
                        join gateway in _gatewayRepository.AsQueryableAsync() on firmware.GatewayId equals gateway.Id
                        join manufacturer in _manufacturerRepository.AsQueryableAsync() on gateway.ManufacturerId equals manufacturer.Id
                        select new EndpointViewModel()
                        {
                            Id = endpoint.Id,
                            Name = endpoint.Name,
                            Url = endpoint.Url,
                            GatewayFirmwareName = firmware.Name,
                            GatewayName = gateway.Name,
                            ManufacturerName = manufacturer.Name,
                            ManufacurerWebsite = manufacturer.Website,
                            ManufacturerLogo = manufacturer.Logo,
                            UpdateBy = endpoint.UpdateBy,
                            UpdateDate = endpoint.UpdateDate,
                            CreateBy = endpoint.CreateBy,
                            CreationDate = endpoint.CreationDate,
                            GatewayFirmwareId = endpoint.GatewayFirmwareId,
                            ManufacturerId = manufacturer.Id,
                            GatewayId = gateway.Id

                            //EndpointInfo = endpoint,
                            //FirmwareInfo = firmware,
                            //GatewayInfo = gateway,
                            //ManufacturerInfo = manufacturer
                        };

            cancellationToken.ThrowIfCancellationRequested();

            return await query.ToAsyncEnumerable().ToList();
        }

        public async Task<EndpointViewModel> GetWithDependenciesByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            var query = from endpoint in AsQueryableAsync()
                        join firmware in _firmwareRepository.AsQueryableAsync() on endpoint.GatewayFirmwareId equals firmware.Id
                        join gateway in _gatewayRepository.AsQueryableAsync() on firmware.GatewayId equals gateway.Id
                        join manufacturer in _manufacturerRepository.AsQueryableAsync() on gateway.ManufacturerId equals manufacturer.Id
                        where endpoint.Id == id
                        select new EndpointViewModel()
                        {
                            Id = endpoint.Id,
                            Name = endpoint.Name,
                            Url = endpoint.Url,
                            GatewayFirmwareName = firmware.Name,
                            GatewayName = gateway.Name,
                            ManufacturerName = manufacturer.Name,
                            ManufacurerWebsite = manufacturer.Website,
                            ManufacturerLogo = manufacturer.Logo,
                            UpdateBy = endpoint.UpdateBy,
                            UpdateDate = endpoint.UpdateDate,
                            CreateBy = endpoint.CreateBy,
                            CreationDate = endpoint.CreationDate,
                            GatewayFirmwareId = endpoint.GatewayFirmwareId,
                            ManufacturerId = manufacturer.Id,
                            GatewayId = gateway.Id

                            //EndpointInfo = endpoint,
                            //FirmwareInfo = firmware,
                            //GatewayInfo = gateway,
                            //ManufacturerInfo = manufacturer,
                        };

            cancellationToken.ThrowIfCancellationRequested();

            return await query.ToAsyncEnumerable().FirstOrDefault();
        }
    }
}

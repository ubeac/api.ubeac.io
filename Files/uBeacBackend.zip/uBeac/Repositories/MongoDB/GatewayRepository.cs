﻿using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Repositories.MongoDB;
using uBeac.Models;
using uBeac;
using uBeac.Repositories;

namespace uBeacAPI.Repositories
{
    public class GatewayRepository : BaseEntityRepository<Gateway>, IGatewayRepository
    {
        private readonly IManufacturerRepository _manufacturerRepository;
        public GatewayRepository(IMongoDatabase database, IManufacturerRepository manufacturerRepository) : base(database)
        {
            _manufacturerRepository = manufacturerRepository;
        }
        protected override string CollectionName { get => "GatewaysDef"; }

        public bool DoesManufacturerExist(string manufacturerId, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            manufacturerId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
                        
            return (_manufacturerRepository.GetByIdAsync(manufacturerId).Result != null);
        }

        public bool DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            var query = Builders<Gateway>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"));
            cancellationToken.ThrowIfCancellationRequested();

            return (Collection.Find(query).FirstOrDefault() != null);
        }

        public bool DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            var query = Builders<Gateway>.Filter.And(
                Builders<Gateway>.Filter.Not(Builders<Gateway>.Filter.Eq(m => m.Id, id)),
                Builders<Gateway>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"))
                );
            cancellationToken.ThrowIfCancellationRequested();

            return (Collection.Find(query).FirstOrDefault() != null);
        }

        protected override async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            var pack = ConventionRegistry.Lookup(typeof(CamelCaseElementNameConvention));

            var nameKeyBuilder = Builders<Gateway>.IndexKeys.Ascending(gateway => gateway.Name);            

            var tasks = new[]
            {
                Collection.Indexes.CreateOneAsync(nameKeyBuilder, new CreateIndexOptions { Unique = true, Name ="IDX_GatewayName" })
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);
        }

        public async Task<IList<Gateway>> GetByManufacturerIdAsync(string manufacturerId, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            manufacturerId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
            FilterDefinition<Gateway> query = Builders<Gateway>.Filter.Eq(x => x.ManufacturerId, manufacturerId);

            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.ToList();
        }        
    }    
}
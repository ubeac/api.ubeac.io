﻿using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac;
using uBeac.Models;
using uBeac.Repositories;
using uBeac.Repositories.MongoDB;

namespace uBeacAPI.Repositories
{
    public class ManufacturerRepository : BaseEntityRepository<Manufacturer>, IManufacturerRepository
    {
        public ManufacturerRepository(IMongoDatabase database) : base(database)
        {          
        }
        protected override string CollectionName { get => "Manufacturers"; }

        public async Task<bool> DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            var query = Builders<Manufacturer>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"));
            cancellationToken.ThrowIfCancellationRequested();            

            return await Task.FromResult(Collection.Find(query).FirstOrDefault() != null);
        }

        public async Task<bool> DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            name.ThrowIfNull();
            
            var query = Builders<Manufacturer>.Filter.And(
                Builders<Manufacturer>.Filter.Not(Builders<Manufacturer>.Filter.Eq(m => m.Id, id)),
                Builders<Manufacturer>.Filter.Regex(m => m.Name, new MongoDB.Bson.BsonRegularExpression("/^" + name + "$/i"))
                );
            cancellationToken.ThrowIfCancellationRequested();

            return await Task.FromResult(Collection.Find(query).FirstOrDefault() != null);
        }

        protected override async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            var pack = ConventionRegistry.Lookup(typeof(CamelCaseElementNameConvention));

            var nameKeyBuilder = Builders<Manufacturer>.IndexKeys.Ascending(manufacturer => manufacturer.Name);            

            var tasks = new[]
            {
                Collection.Indexes.CreateOneAsync(nameKeyBuilder, new CreateIndexOptions { Unique = true, Name ="IDX_ManufacturerName" })                
            };

            await Task.WhenAll(tasks).ConfigureAwait(false);

        }

    }
}
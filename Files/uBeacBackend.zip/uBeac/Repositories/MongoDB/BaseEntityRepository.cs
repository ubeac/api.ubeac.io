﻿using MongoDB.Driver;
using System;
using uBeac.Models;

namespace uBeac.Repositories.MongoDB
{
    public abstract class BaseEntityRepository<TEntity> : MongoGenericRepository<TEntity> where TEntity : BaseEntity
    {
        public BaseEntityRepository(IMongoDatabase database) : base(database)
        {
        }

        protected override string GetIdValue(TEntity entity) => 
            entity.Id;

        protected override void SetIdValue(TEntity entity)=> 
            entity.Id = Guid.NewGuid().ToString();
        
    }
}

﻿using MongoDB.Driver;
using uBeac.Models;
using uBeac.Repositories;
using uBeac.Repositories.MongoDB;

namespace uBeacAPI.Repositories
{
    public class TeamRepository : BaseEntityRepository<Team>, ITeamRepository
    {
        public TeamRepository(IMongoDatabase database) : base(database)
        {
        }
        protected override string CollectionName { get => "Teams"; }
        protected override string GetIdValue(Team entity) => entity.Id;                          
    }    
}
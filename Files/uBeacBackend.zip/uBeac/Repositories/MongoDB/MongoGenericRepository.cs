﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace uBeac.Repositories.MongoDB
{
    public abstract class MongoGenericRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {

        public readonly IMongoDatabase Database;
        public readonly IMongoCollection<TEntity> Collection;

        public MongoGenericRepository(IMongoDatabase database)
        {
            database.ThrowIfNull();
            CollectionName.ThrowIfNull();

            Database = database;
            Collection = Database.GetCollection<TEntity>(CollectionName);

            EnsureIndicesCreatedAsync().GetAwaiter().GetResult();
        }

        public virtual async Task<TEntity> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            id.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var result = await Collection.FindOneAndDeleteAsync(GetIdFilter(id), cancellationToken: cancellationToken).ConfigureAwait(false);
            return result;
        }

        public virtual async Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            id.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var result = await Collection.FindAsync(GetIdFilter(id), cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await Collection.AsQueryable().ToListAsync();
        }

        public virtual async Task<TEntity> InsertAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            entity.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();
            SetIdValue(entity);

            await Collection.InsertOneAsync(entity, cancellationToken: cancellationToken).ConfigureAwait(false);
            return entity;
        }

        public virtual async Task<TEntity> UpdateAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            entity.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            GetIdValue(entity).ThrowIfNull();

            var replaceResult = await Collection.ReplaceOneAsync(GetIdFilter(GetIdValue(entity)), entity, new UpdateOptions { IsUpsert = false }).ConfigureAwait(false);

            if (replaceResult.ModifiedCount == 1)
            {
                return entity;
            }
            else
            {
                throw new Exception("Unhandled repository exception for Update!!!");
            }

        }
        
        public virtual IQueryable<TEntity> AsQueryableAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return Collection.AsQueryable();
        }

        protected FilterDefinition<TEntity> GetIdFilter(string id)
        {
            var query_id = Builders<TEntity>.Filter.Eq("_id", id);
            return query_id;
        }

        protected abstract string CollectionName { get; }
        protected abstract string GetIdValue(TEntity entity);
        protected abstract void SetIdValue(TEntity entity);

        #region Initialize DB

        private static bool _initialized = false;
        private static object _initializationLock = new object();
        private static object _initializationTarget;

        protected virtual async Task EnsureIndicesCreatedAsync()
        {
            var obj = LazyInitializer.EnsureInitialized(ref _initializationTarget, ref _initialized, ref _initializationLock, () =>
            {
                return EnsureIndicesCreatedDefinitionsAsync();
            });

            if (obj != null)
            {
                var taskToAwait = (Task)obj;
                await taskToAwait.ConfigureAwait(false);
            }
        }

        protected virtual async Task EnsureIndicesCreatedDefinitionsAsync()
        {
            await Task.FromResult(0);
        }

        #endregion Initialize DB 

        #region Disposable

        private bool _disposed = false;
        public void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        public void Dispose()
        {
            _disposed = true;
        }

        #endregion


    }
}

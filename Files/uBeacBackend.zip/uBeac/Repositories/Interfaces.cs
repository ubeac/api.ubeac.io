﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;

namespace uBeac.Repositories
{

    public interface IGatewayFirmwareRepository : IRepository<GatewayFirmware>
    {
        Task<IList<GatewayFirmware>> GetByGatewayIdAsync(string gatewayId, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesGatewayExist(string gatewayId, CancellationToken cancellationToken = default(CancellationToken));
        //Task<IList<ManufacturerViewModel>> GetHierarchyAsync(CancellationToken cancellationToken = default(CancellationToken));
    }

    public interface IGatewayRepository : IRepository<Gateway>
    {
        Task<IList<Gateway>> GetByManufacturerIdAsync(string manufacturerId, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken));
        bool DoesManufacturerExist(string manufacturerId, CancellationToken cancellationToken = default(CancellationToken));
    }

    public interface IManufacturerRepository : IRepository<Manufacturer>
    {
        Task<bool> DoesNameExist(string name, CancellationToken cancellationToken = default(CancellationToken));
        Task<bool> DoesNameExist(string id, string name, CancellationToken cancellationToken = default(CancellationToken));
        
    }

    public interface ITeamRepository : IRepository<Team>
    {
        
    }
        
    public interface IEndpointRepository : IRepository<Endpoint>
    {
        Task<bool> DoesUrlExist(string url, CancellationToken cancellationToken = default(CancellationToken));
        Task<bool> DoesUrlExist(string Id, string url, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<Endpoint>> GetByFirmwareIdAsync(string firmwareId, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<EndpointViewModel>> GetAllByDependenciesAsync(CancellationToken cancellationToken = default(CancellationToken));
        Task<EndpointViewModel> GetWithDependenciesByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken)); 
        Task<Endpoint> GetByUrlAsync(string url, CancellationToken cancellationToken = default(CancellationToken));
    }

    //public interface IUserRepository : IRepository<User>
    //{
    //    bool DoesEmailExist(string email, CancellationToken cancellationToken = default(CancellationToken));
    //    bool DoesEmailExist(string Id, string email, CancellationToken cancellationToken = default(CancellationToken));
    //    bool CanChangePassword(string Id, string oldPassword, string newPassword, CancellationToken cancellationToken = default(CancellationToken));
    //    Task<bool> ChangePasswordAsync(string Id, string newPassword, CancellationToken cancellationToken = default(CancellationToken));
    //}

}

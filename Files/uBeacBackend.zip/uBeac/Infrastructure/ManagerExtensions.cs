﻿using uBeac.Infrastructure;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ManagerExtensions
    {
        public static IServiceCollection AddManager(this IServiceCollection services)
        {
            services.AddSingleton<Manager>();
            return services;
        }
    }
}
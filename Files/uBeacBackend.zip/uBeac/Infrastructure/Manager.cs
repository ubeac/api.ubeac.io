﻿namespace uBeac.Infrastructure
{
    public class Manager
    {
        //public IConfiguration Configuration { get; }
        //public IHostingEnvironment HostingEnvironment { get; }

        //public Manager(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        //{
        //    Configuration = configuration;
        //    HostingEnvironment = hostingEnvironment;
        //}

    }

    
}


﻿using MessagePack;

namespace uBeac.Serialization
{
    public class MessageSerializer : IMessageSerializer
    {
        public T Deserialize<T>(byte[] bytes)
        {
            var data = MessagePackSerializer.Deserialize<T>(bytes);
            return data;
        }

        public byte[] Serialize<T>(T value)
        {
            var bytes = MessagePackSerializer.Serialize(value);
            return bytes;
        }
    }
}

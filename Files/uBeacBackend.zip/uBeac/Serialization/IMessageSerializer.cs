﻿namespace uBeac.Serialization
{
    public interface IMessageSerializer
    {
        byte[] Serialize<T>(T value);
        T Deserialize<T>(byte[] bytes);
    }
}

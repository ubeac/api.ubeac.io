﻿using System.Collections.Generic;

namespace uBeac.Models
{
    public class Manufacturer : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Website { get; set; }
        public string Logo { get; set; }
    }

    public class ManufacturerViewModel
    {
        public string Id { get; set; }
        public Manufacturer Manufacturer { get; set; }
        public IList<GatewayViewModel> Gateways { get; set; }
    }
    public class GatewayViewModel
    {
        public string Id { get; set; }
        public Gateway Gateway { get; set; }
        public IList<GatewayFirmware> Firmwares { get; set; }
    }
}
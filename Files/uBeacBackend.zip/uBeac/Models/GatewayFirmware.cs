﻿using System;

namespace uBeac.Models
{
    public class GatewayFirmware: BaseEntity
    {
        public string GatewayId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string TechnicalSpecFile { get; set; }
    }
}
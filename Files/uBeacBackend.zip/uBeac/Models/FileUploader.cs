﻿namespace uBeac.Models
{
    public class FileUploader: BaseEntity
    {
        public string Name { get; set; }
        public string Extension { get; set; }
        public long Size { get; set; }
    }
}

﻿namespace uBeac.Models
{
    public class Gateway:BaseEntity
    {
        public string ManufacturerId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string ManualFile { get; set; }
        public string TechnicalSpecFile { get; set; }
    }
}
﻿namespace uBeac.Models
{
    public class Endpoint: BaseEntity
    {
        public string GatewayFirmwareId { get; set; }
        public string Url { get; set; }
        public string Name { get; set; }
    }

    public class EndpointViewModel : BaseEntity
    {
        public string GatewayFirmwareId { get; set; }
        public string Url { get; set; }
        public string Name { get; set; }
        public string GatewayFirmwareName { get; set; }
        public string GatewayId { get; set; }
        public string GatewayName { get; set; }
        public string ManufacturerId { get; set; }
        public string ManufacturerName { get; set; }
        public string ManufacurerWebsite { get; set; }
        public string ManufacturerLogo { get; set; }
        //public Endpoint EndpointInfo { get; set; }
        //public Gateway GatewayInfo { get; set; }
        //public GatewayFirmware FirmwareInfo { get; set; }
        //public Manufacturer ManufacturerInfo { get; set; }
    }
}
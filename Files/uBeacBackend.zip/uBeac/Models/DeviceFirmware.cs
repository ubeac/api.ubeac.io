﻿using System;

namespace uBeac.Models
{
    public class DeviceFirmware
    {
        public string Id { get; set; }
        public string DeviceId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string TechnicalSpecFile { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime UpdateDate { get; set; }
        public string CreateBy { get; set; }
        public string UpdateBy { get; set; }
    }
}
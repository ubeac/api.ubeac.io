﻿using RabbitMQ.Client.Events;
using System;

namespace uBeac.Messaging
{
    public interface IMessageReceiver : IDisposable
    {
        void OnRecieved(object sender, BasicDeliverEventArgs eventArgs);
    }
}

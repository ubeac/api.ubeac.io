﻿using System;

namespace uBeac.Messaging
{
    public interface IMessageSender : IDisposable
    {
        void Send(byte[] bytes);
    }
}

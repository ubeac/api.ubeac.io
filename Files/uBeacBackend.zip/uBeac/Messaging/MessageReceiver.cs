﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace uBeac.Messaging
{
    public class MessageReceiver : IMessageReceiver
    {
        protected readonly IConnection Connection;
        protected readonly IModel Channel;

        public MessageReceiver(MessageBrokerConfig config)
        {

            var factory = new ConnectionFactory()
            {
                HostName = config.HostName
            };

            Connection = factory.CreateConnection();
            Channel = Connection.CreateModel();
            Channel.ExchangeDeclare(exchange: config.ExchangeName, type: config.ExchangeType);

            var queueName = Channel.QueueDeclare().QueueName;
            Channel.QueueBind(queue: queueName, exchange: config.ExchangeName, routingKey: config.RoutingKey);

            var consumer = new EventingBasicConsumer(Channel);
            consumer.Received += (model, ea) =>
            {
                OnRecieved(model, ea);
            };
            Channel.BasicConsume(queue: queueName, autoAck: true, consumer: consumer);

        }

        public void Dispose()
        {
            Channel.Close();
            Channel.Dispose();
            Connection.Close();
            Connection.Dispose();
        }

        public virtual void OnRecieved(object sender, BasicDeliverEventArgs eventArgs)
        {
            var body = eventArgs.Body;
        }
    }
}

﻿namespace uBeac.Messaging
{
    public class MessageBrokerConfig
    {
        public string HostName { get; set; }
        public string ExchangeName { get; set; }
        public string ExchangeType { get; set; }
        public string RoutingKey { get; set; }
    }
}

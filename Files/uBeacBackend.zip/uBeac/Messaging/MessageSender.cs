﻿using RabbitMQ.Client;

namespace uBeac.Messaging
{
    public class MessageSender : IMessageSender
    {
        protected readonly IConnection Connection;
        protected readonly IModel Channel;
        protected readonly MessageBrokerConfig Config;

        public MessageSender(MessageBrokerConfig config)
        {

            config.ThrowIfNull();

            Config = config;

            var factory = new ConnectionFactory()
            {
                HostName = config.HostName
            };

            Connection = factory.CreateConnection();
            Channel = Connection.CreateModel();
            Channel.ExchangeDeclare(exchange: config.ExchangeName, type: config.ExchangeType);

        }

        public void Dispose()
        {
            Channel.Close();
            Channel.Dispose();
            Connection.Close();
            Connection.Dispose();
        }

        public virtual void Send(byte[] bytes)
        {
            Channel.BasicPublish(exchange: Config.ExchangeName, routingKey: Config.RoutingKey, basicProperties: null, body: bytes);
        }
    }
    
}

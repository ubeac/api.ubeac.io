﻿namespace uBeac
{
    public class Manager
    {
        public AppConfig AppConfig { get; }

        public Manager(AppConfig appConfig)
        {
            AppConfig = appConfig;
        }
    }
}

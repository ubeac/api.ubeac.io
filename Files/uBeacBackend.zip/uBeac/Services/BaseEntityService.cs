﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{

    public abstract class BaseEntityService<TEntity> : IBaseEntityService<TEntity>
        where TEntity : BaseEntity
    {
        public readonly IRepository<TEntity> Repository;

        public BaseEntityService(IRepository<TEntity> repository)
        {
            repository.ThrowIfNull();
            Repository = repository;
        }

        public virtual async Task<TEntity> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();            
            cancellationToken.ThrowIfCancellationRequested();

            return await Repository.DeleteAsync(id, cancellationToken);
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await Repository.GetAllAsync(cancellationToken);
        }

        public virtual async Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();            
            cancellationToken.ThrowIfCancellationRequested();
            
            return await Repository.GetByIdAsync(id, cancellationToken);
        }

        public virtual async Task<TEntity> AddAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();            
            cancellationToken.ThrowIfCancellationRequested();

            entity.PrepareForInsert();

            return await Repository.InsertAsync(entity, cancellationToken);
        }

        public virtual async Task<TEntity> UpdateAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();            
            cancellationToken.ThrowIfCancellationRequested();

            entity.PrepareForUpdate();

            return await Repository.UpdateAsync(entity, cancellationToken);
        }

        #region Disposable

        private bool _disposed = false;
        public void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        public void Dispose()
        {
            _disposed = true;
        }

        #endregion
    }
}

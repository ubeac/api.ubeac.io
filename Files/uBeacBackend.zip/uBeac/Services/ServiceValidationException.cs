﻿using System;

namespace uBeac.Services
{
    public class ServiceValidationException : Exception
    {
        public ServiceValidationException() : this("")
        {
        }
        public ServiceValidationException(string message) : base(message)
        {
        }
    }
}

﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{
    public class ManufacturerService : 
        BaseEntityService<Manufacturer>,
        IManufacturerService
    {
        private IManufacturerRepository _repository;
        private IGatewayService _gatewayService;
        private IGatewayFirmwareService _firmwareService;

        public ManufacturerService(IManufacturerRepository repository, IGatewayService gatewayService, IGatewayFirmwareService firmwareService) :base(repository)
        {
            _repository = repository;
            _gatewayService = gatewayService;
            _firmwareService = firmwareService;
        }

        public override async Task<Manufacturer> AddAsync(Manufacturer model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            if (await _repository.DoesNameExist(model.Name))
                throw new ServiceValidationException("Duplicate name was found");
            
            return await base.AddAsync(model);
        }

        public override async Task<Manufacturer> UpdateAsync(Manufacturer model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();            
            cancellationToken.ThrowIfCancellationRequested();

            Manufacturer existingManufacturer = await _repository.GetByIdAsync(model.Id);
            existingManufacturer.ThrowIfNull();

            if (await _repository.DoesNameExist(model.Id, model.Name))
                throw new ServiceValidationException("Duplicate name was found");
            
            return await base.UpdateAsync(model);
        }

        public async Task<IList<ManufacturerViewModel>> GetHierarchy(bool hierarchy, CancellationToken cancellationToken = default(CancellationToken))
        {
            IList<ManufacturerViewModel> ManufacturersList = new List<ManufacturerViewModel>();

            var manufacturerList = await _repository.GetAllAsync();
            foreach (Manufacturer manufacturer in manufacturerList)
            {
                if (manufacturer.Id != null)
                {
                    List<GatewayViewModel> GatewaysList = new List<GatewayViewModel>();
                    var gatewayList = await _gatewayService.GetByManufacturerIdAsync(manufacturer.Id);

                    foreach (Gateway gateway in gatewayList)
                    {
                        var firmwareList = await _firmwareService.GetByGatewayIdAsync(gateway.Id);
                        GatewayViewModel Gateways = new GatewayViewModel()
                        {
                            Gateway = gateway,
                            Firmwares = firmwareList
                        };
                        GatewaysList.Add(Gateways);
                    }

                    ManufacturerViewModel Manufacturers = new ManufacturerViewModel()
                    {
                        Manufacturer = manufacturer,
                        Gateways = GatewaysList
                    };
                    ManufacturersList.Add(Manufacturers);
                }
            }

            return ManufacturersList;
        }
                
    }

    public interface IManufacturerService: IBaseEntityService<Manufacturer>
    {
        Task<IList<ManufacturerViewModel>> GetHierarchy(bool hierarchy, CancellationToken cancellationToken = default(CancellationToken));
    }

}

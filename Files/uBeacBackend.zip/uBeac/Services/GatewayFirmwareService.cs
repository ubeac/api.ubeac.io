﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{

    public class GatewayFirmwareService : BaseEntityService<GatewayFirmware>, IGatewayFirmwareService
    {
        IGatewayFirmwareRepository _repository;
        public GatewayFirmwareService(IGatewayFirmwareRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public override async Task<GatewayFirmware> AddAsync(GatewayFirmware model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            if (!_repository.DoesGatewayExist(model.GatewayId))
                throw new ServiceValidationException("Gateway not found");

            if (_repository.DoesNameExist(model.Name))
                throw new ServiceValidationException("Duplicate name founded");

            return await base.AddAsync(model);
        }

        public override async Task<GatewayFirmware> UpdateAsync(GatewayFirmware model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            GatewayFirmware existingFirmware = await _repository.GetByIdAsync(model.Id);
            existingFirmware.ThrowIfNull();

            if (!_repository.DoesGatewayExist(model.GatewayId))
                throw new ServiceValidationException("Gateway not found");

            if (_repository.DoesNameExist(model.Id, model.Name))
                throw new ServiceValidationException("Duplicate name founded");

            return await base.UpdateAsync(model);
        }

        public async Task<IList<GatewayFirmware>> GetByGatewayIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            var firmwareList = await _repository.GetByGatewayIdAsync(id);

            //if (firmwareList.Count == 0)
            //    throw new ServiceValidationException("No gateway was found for this manufacturer!");

            return firmwareList;
        }
                
    }

    public interface IGatewayFirmwareService : IBaseEntityService<GatewayFirmware>
    {
        Task<IList<GatewayFirmware>> GetByGatewayIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));        
    }
}

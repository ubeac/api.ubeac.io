﻿using System.Threading;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{
    public class TeamService : BaseEntityService<Team>, ITeamService
    {
        private ITeamRepository _repository;
        public TeamService(ITeamRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public override async Task<Team> AddAsync(Team model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await base.AddAsync(model);
        }

        public override async Task<Team> UpdateAsync(Team model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await base.UpdateAsync(model);
        }        
    }

    public interface ITeamService : IBaseEntityService<Team>
    {
        
    }
}

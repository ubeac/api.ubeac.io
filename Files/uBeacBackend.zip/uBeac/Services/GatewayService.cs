﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{
    public class GatewayService : BaseEntityService<Gateway>, IGatewayService
    {
        private IGatewayRepository _repository;
        public GatewayService(IGatewayRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public override async Task<Gateway> AddAsync(Gateway model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            if (!_repository.DoesManufacturerExist(model.ManufacturerId))
                throw new ServiceValidationException("Manufacturer not found");

            if (_repository.DoesNameExist(model.Name))
                throw new ServiceValidationException("Duplicate name founded");

            return await base.AddAsync(model);            
        }
                
        public override async Task<Gateway> UpdateAsync(Gateway model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            Gateway existingGateway = await _repository.GetByIdAsync(model.Id);
            existingGateway.ThrowIfNull();

            if (! _repository.DoesManufacturerExist(model.ManufacturerId))
                throw new ServiceValidationException("Manufacturer not found");

            if (_repository.DoesNameExist(model.Id, model.Name))
                throw new ServiceValidationException("Duplicate name found");

            return await base.UpdateAsync(model);
        }

        public async Task<IList<Gateway>> GetByManufacturerIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            var gatewayList = await _repository.GetByManufacturerIdAsync(id);
            
            //if (gatewayList.Count == 0)
            //    throw new ServiceValidationException("No gateway was found for this manufacturer!");

            return gatewayList;
        }
    }

    public interface IGatewayService : IBaseEntityService<Gateway>
    {
        Task<IList<Gateway>> GetByManufacturerIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;
using uBeac.Repositories;
using uBeacAPI.Repositories;

namespace uBeac.Services
{
    public class FileService : IFileService
    {
        private IFileRepository _repository;

        public FileService(IFileRepository repository)
        {
            repository.ThrowIfNull();
            _repository = repository;
        }

        public async Task<FileUploader> AddAsync(string fileName, long fileSize, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            FileUploader model = new FileUploader
            {
                Name = Path.GetFileNameWithoutExtension(fileName),
                Extension = Path.GetExtension(fileName),
                Size = fileSize
            };

            string[] mime = FileType.GetMimeType(model.Extension).Split('/');
            model.PrepareForInsert();
            return await _repository.InsertAsync(model);
        }

        public readonly IRepository<FileUploader> Repository;

        public FileService(IRepository<FileUploader> repository)
        {
            repository.ThrowIfNull();
            Repository = repository;
        }

        public virtual async Task<FileUploader> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await _repository.DeleteAsync(id, cancellationToken);
        }

        public virtual async Task<IEnumerable<FileUploader>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await _repository.GetAllAsync(cancellationToken);
        }

        public virtual async Task<FileUploader> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            return await _repository.GetByIdAsync(id, cancellationToken);
        }

        public virtual async Task<FileUploader> AddAsync(FileUploader entity, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            entity.PrepareForInsert();

            return await _repository.InsertAsync(entity, cancellationToken);
        }

        #region Disposable

        private bool _disposed = false;
        public void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        public void Dispose()
        {
            _disposed = true;
        }

        #endregion


    }

    public interface IFileService : IDisposable
    {
        Task<FileUploader> AddAsync(string fileName, long fileSize, CancellationToken cancellationToken = default(CancellationToken));
        Task<FileUploader> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<FileUploader> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<IEnumerable<FileUploader>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken));
    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Models;

namespace uBeac.Services
{
    public interface IBaseEntityService<TEntity> :
        IDisposable
        where TEntity : BaseEntity
    {
        Task<TEntity> AddAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> UpdateAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken));
    }
}

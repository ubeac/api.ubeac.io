﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using uBeac.Api;
using uBeac.Models;
using uBeac.Repositories;

namespace uBeac.Services
{
    public class EndpointService : BaseEntityService<Endpoint>, IEndpointService
    {
        private IEndpointRepository _repository;

        public EndpointService(IEndpointRepository repository) : base(repository)
        {
            _repository = repository;
        }

        public override async Task<Endpoint> AddAsync(Endpoint model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            if (await _repository.DoesUrlExist(model.Url))
                throw new ServiceValidationException("Duplicate url founded");

            return await base.AddAsync(model);
        }

        public override async Task<Endpoint> UpdateAsync(Endpoint model, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();

            Endpoint existingEndpoint = await _repository.GetByIdAsync(model.Id);
            existingEndpoint.ThrowIfNull();

            if (await _repository.DoesUrlExist(model.Id, model.Url))
                throw new ServiceValidationException("Duplicate url founded");

            return await base.UpdateAsync(model);
        }

        public async Task<IList<Endpoint>> GetByFirmwareIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            var endpointList = await _repository.GetByFirmwareIdAsync(id);

            if (endpointList.Count == 0)
                throw new ServiceValidationException("No endpoint was found for this firmware!");

            return endpointList;
        }

        public async Task<IList<EndpointViewModel>> GetAllByDependenciesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            var endpointList = await _repository.GetAllByDependenciesAsync();

            if (endpointList.Count == 0)
                throw new ServiceValidationException("No endpoint found!");

            return endpointList;
        }

        public async Task<EndpointViewModel> GetWithDependenciesByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            var endpoint = await _repository.GetWithDependenciesByIdAsync(id);
            endpoint.ThrowIfNull();
            
            return endpoint;
        }

        public async Task<bool> DoesUrlExist(string url, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            
            return await await Task.FromResult(_repository.DoesUrlExist(url));
        }

        public async Task<Endpoint> GetByUrlAsync(string url, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            cancellationToken.ThrowIfCancellationRequested();
            Endpoint endpoint = await _repository.GetByUrlAsync(url);
            
            if (endpoint is null)
                throw new ServiceValidationException("No endpoint was found for this firmware!");

            return endpoint;
        }
    }

    public interface IEndpointService : IBaseEntityService<Endpoint>
    {
        Task<IList<Endpoint>> GetByFirmwareIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<EndpointViewModel>> GetAllByDependenciesAsync(CancellationToken cancellationToken = default(CancellationToken));
        Task<EndpointViewModel> GetWithDependenciesByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<bool> DoesUrlExist(string url, CancellationToken cancellationToken = default(CancellationToken));
        Task<Endpoint> GetByUrlAsync(string url, CancellationToken cancellationToken = default(CancellationToken));
    }
}

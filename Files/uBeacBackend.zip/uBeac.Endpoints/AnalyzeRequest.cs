﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;

namespace uBeac.Endpoints
{
    public class AnalyzeRequest
    {
        public static bool IsMobile(HttpRequest request)
        {
            Regex MobileCheck = new Regex(@"android|(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
            Regex MobileVersionCheck = new Regex(@"1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-", RegexOptions.IgnoreCase | RegexOptions.Multiline | RegexOptions.Compiled);
            if (request != null && request.Headers["User-Agent"] != "")
            {
                var u = request.Headers["User-Agent"].ToString();

                if (u.Length < 4)
                    return false;

                if (MobileCheck.IsMatch(u) || MobileVersionCheck.IsMatch(u.Substring(0, 4)))
                    return true;
            }
            
            return false;
        }

        public static string GetComputerName(string ip)
        {
            var myIP = IPAddress.Parse(ip);
            IPHostEntry GetIPHost = Dns.GetHostEntry(myIP);
            List<string> compName = GetIPHost.HostName.ToString().Split('.').ToList();
            return compName.First();
        }

        public static String GetUserEnvironment(HttpRequest request)
        {
            var browser = request.Headers["User-Agent"];
            var platform = GetUserPlatform(request);
            // return string.Format("{0} {1} / {2}", browser.Browser, browser.Version, platform);
            
            return platform;
        }

        public static String GetUserPlatform(HttpRequest request)
        {
            string ua = request.Headers["User-Agent"].ToString();

            if (ua.IndexOf("Android") > 0)
                return string.Format("Android {0}", GetMobileVersion(ua, "Android"));

            if (ua.IndexOf("iPad") > 0)
                return string.Format("iPad OS {0}", GetMobileVersion(ua, "OS"));

            if (ua.IndexOf("iPhone") > 0)
                return string.Format("iPhone OS {0}", GetMobileVersion(ua, "OS"));

            if (ua.IndexOf("Linux") > 0 && ua.IndexOf("KFAPWI") > 0)
                return "Kindle Fire";

            if (ua.IndexOf("RIM Tablet") > 0 || (ua.IndexOf("BB") > 0 && ua.IndexOf("Mobile") > 0))
                return "Black Berry";

            if (ua.IndexOf("Windows Phone") > 0)
                return string.Format("Windows Phone {0}", GetMobileVersion(ua, "Windows Phone"));

            if (ua.IndexOf("Mac OS") > 0)
                return "Mac OS";

            if (ua.IndexOf("Windows NT 5.1") > 0 || ua.IndexOf("Windows NT 5.2") > 0)
                return "Windows XP";

            if (ua.IndexOf("Windows NT 6.0") > 0)
                return "Windows Vista";

            if (ua.IndexOf("Windows NT 6.1") > 0)
                return "Windows 7";

            if (ua.IndexOf("Windows NT 6.2") > 0)
                return "Windows 8";

            if (ua.IndexOf("Windows NT 6.3") > 0)
                return "Windows 8.1";

            if (ua.IndexOf("Windows NT 10") > 0)
                return "Windows 10";

            //fallback to basic platform:
            //return request.Browser.Platform + (ua.Contains("Mobile") ? " Mobile " : "");
            return "";
        }

        public static String GetMobileVersion(string userAgent, string device)
        {
            var temp = userAgent.Substring(userAgent.IndexOf(device) + device.Length).TrimStart();
            var version = string.Empty;

            foreach (var character in temp)
            {
                var validCharacter = false;
                int test = 0;

                if (Int32.TryParse(character.ToString(), out test))
                {
                    version += character;
                    validCharacter = true;
                }

                if (character == '.' || character == '_')
                {
                    version += '.';
                    validCharacter = true;
                }

                if (validCharacter == false)
                    break;
            }

            return version;
        }

        public static RequestInfo GetRequestInfo(HttpRequest request)
        {
            var Request = new RequestInfo()
            {
                Method = request.Method,
                ContentType = request.ContentType,
                ContentLength = request.ContentLength,
                Host = request.Host.Host,
                Port = request.Host.Port,
                Scheme = request.Scheme,
                QueryString = request.QueryString.ToString(),
                Protocol = request.Protocol,
                HasFormContentType = request.HasFormContentType,
                Path = request.Path.Value,
                Headers = request.Headers.ToDictionary(item => item.Key, item => item.Value.ToList()),
                Content = new StreamReader(request.Body).ReadToEnd(),
            };
            return Request;
        }

        public static ClientInfo GetClientInfo(HttpRequest request)
        {
            var client = new ClientInfo()
            {
                Ip = request.HttpContext.Connection.RemoteIpAddress.ToString(),
                Port = request.HttpContext.Connection.RemotePort.ToString(),
                HostName = AnalyzeRequest.GetComputerName(request.HttpContext.Connection.RemoteIpAddress.ToString()),
                UserAgent = request.Headers["User-Agent"],
                IsMobile = AnalyzeRequest.IsMobile(request),
                UserEnvironment = AnalyzeRequest.GetUserEnvironment(request),
            };
            return client;
        }
    }
}

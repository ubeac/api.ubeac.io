﻿using System;
using System.IO;
using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using uBeac.Repositories;
using uBeac.Services;
using uBeacAPI.Repositories;

namespace uBeac.Endpoints
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton(Configuration);
            services.AddDatabase(Configuration);
            services.AddScoped<IEndpointRepository, EndpointRepository>();
            services.AddScoped<IEndpointService, EndpointService>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IServiceProvider serviceProvider)
        {

            app.Run(async context =>
            {

                //check if the url is less than 2 it is not correct
                if (context.Request.Path.Value.Length < 2)
                {
                    context.Response.StatusCode = 404;
                    //await context.Response.WriteAsync(string.Empty);
                    return;
                }

                try
                {

                    var url = context.Request.Path.Value.Remove(0, 1);
                    var endpointService = serviceProvider.GetService<IEndpointService>();
                    var endpoint = await endpointService.GetByUrlAsync(url);

                    if (endpoint == null)
                    {
                        context.Response.StatusCode = 404;
                        //await context.Response.WriteAsync(string.Empty);
                        return;
                    }

                    var data = GetPostedData(context);
                    data.EndpointId = endpoint.Id;
                    data.FirmwareId = endpoint.GatewayFirmwareId;

                    context.Response.StatusCode = 200;
                    await context.Response.WriteAsync(JsonConvert.SerializeObject(data));

                }
                catch (Exception ex)
                {
                    context.Response.StatusCode = 500;
                    await context.Response.WriteAsync(ex.Message);
                }

            });

        }

        private PostedData GetPostedData(HttpContext context)
        {
            var request = context.Request;
            var response = context.Response;

            var data = new PostedData()
            {
                TraceId = context.TraceIdentifier,
                Date = DateTime.UtcNow,
                Method = request.Method,
                ContentType = request.ContentType,
                ContentLength = request.ContentLength,
                Host = request.Host.Host,
                Port = request.Host.Port,
                Scheme = request.Scheme,
                QueryString = request.QueryString.ToString(),
                Protocol = request.Protocol,
                HasFormContentType = request.HasFormContentType,
                Path = request.Path.Value,
                Headers = request.Headers.ToDictionary(item => item.Key, item => item.Value.ToList()),
                Content = new StreamReader(request.Body).ReadToEnd(),
            };
            return data;
        }
    }
}

//namespace uBeac.Endpoints
//{
//    public class Startup
//    {
//        public IConfiguration Configuration { get; }

//        public Startup(IConfiguration configuration)
//        {
//            Configuration = configuration;            
//        }

//        public void ConfigureServices(IServiceCollection services)
//        {
//            services.TryAddSingleton<MainService>();
//            services.TryAddSingleton<IPublisher<EndpointRecData>, Publisher<EndpointRecData>>();
//            services.AddSingleton(Configuration);
//            services
//                .AddRepositories(Configuration)
//                .AddServices();
//        }

//        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IServiceProvider serviceProvider)
//        {
//            //app.UseMiddleware<RequestDataMiddleware>();
//            //var publisher = app.ApplicationServices.GetService<IPublisher<EndpointRecData>>();

//            app.Run(async context =>
//            {
//                var requestService = serviceProvider.GetService<IRequestDataService>();
//                var endpointService = serviceProvider.GetService<IEndpointService>();                
//                try
//                {                    
//                    var mainService = app.ApplicationServices.GetService<MainService>();
//                    string url;
//                    string endpointId = "";
//                    string firmwareId = "";
//                    if (context.Request.Path.Value.Length > 1)
//                    {
//                        url = context.Request.Path.Value.Remove(0, 1);
//                        Models.Endpoint myEndpoint = await endpointService.GetEndpointByUrl(url);

//                        endpointId = myEndpoint.Id;
//                        firmwareId = myEndpoint.GatewayFirmwareId;
//                    }
//                    else                    
//                        url = context.Request.Path.Value;                    

//                    if (string.IsNullOrEmpty(endpointId) || string.IsNullOrEmpty(firmwareId))                    
//                    {
//                        context.Response.StatusCode = 404;
//                    }
//                    else
//                    {
//                        var data = new EndpointRecData()
//                        {
//                            Data = GetRequestContent(context),
//                            Date = DateTime.UtcNow,
//                            EndpointId = endpointId,
//                            FirmwareId = firmwareId,
//                            TraceId = context.TraceIdentifier

//                        };
//                        context.Request.EnableRewind();
//                        var request = context.Request;
//                        var requestContent = new StreamReader(request.Body).ReadToEnd();
//                        request.Body.Position = 0;
//                        var response = context.Response;
//                        var responseContent = string.Empty;
//                        var error = string.Empty;
//                        Stream originalBody = context.Response.Body;

//                        var traceInfo = new TraceInfo()
//                        {
//                            Id = context.TraceIdentifier,
//                            StartDate = DateTime.UtcNow,
//                            Request = AnalyzeRequest.GetRequestInfo(request),                            
//                            Response = new ResponseInfo()
//                            {
//                                StatusCode = response.StatusCode,
//                                Content = responseContent
//                            },
//                            Client = AnalyzeRequest.GetClientInfo(request)                            
//                        };

//                        context.Items.Add("TraceInfo", traceInfo);

//                        try
//                        {
//                            using (var memStream = new MemoryStream())
//                            {
//                                context.Response.Body = memStream;

//                                //await _next(context);

//                                memStream.Position = 0;
//                                responseContent = new StreamReader(memStream).ReadToEnd();

//                                memStream.Position = 0;
//                                await memStream.CopyToAsync(originalBody);
//                            }
//                        }
//                        catch (Exception ex)
//                        {
//                            error = ex.Message;
//                        }

//                        try
//                        {
//                            context.Response.Body = originalBody;
//                        }
//                        catch (Exception ex)
//                        {
//                            error += ex.Message;
//                        }

//                        traceInfo.EndDate = DateTime.UtcNow;
//                        traceInfo.Error = error;
//                        traceInfo.Duration = (traceInfo.EndDate - traceInfo.StartDate).Ticks;
//                        await requestService.AddAsync(traceInfo);
//                        //await AdminApi.Controllers.RequestDataController.Add(traceInfo);
//                        //publisher.Send(data);
//                        //context.Response.StatusCode = 200;
//                    }

//                    await context.Response.WriteAsync(string.Empty);
//                }
//                catch (Exception ex)
//                {
//                    context.Response.StatusCode = 500;
//                    await context.Response.WriteAsync(ex.Message);
//                }
//            });

//            #region Old Code
//            //app.Run(async context =>
//            //{
//            //    try
//            //    {
//            //        var ioTDataFactory = app.ApplicationServices.GetService<IPublisher<EndpointRecData>>();
//            //        var mainService = app.ApplicationServices.GetService<MainService>();
//            //        var url = context.Request.Path.Value.Remove(0, 1);
//            //        var endpointId = mainService.GetEndpointId(url);
//            //        var gatewayId = mainService.GetGatewayId(url);

//            //        if (string.IsNullOrEmpty(endpointId) || string.IsNullOrEmpty(gatewayId))
//            //        {
//            //            context.Response.StatusCode = 404;
//            //        }
//            //        else
//            //        {
//            //            var data = new EndpointRecData()
//            //            {
//            //                Data = GetRequestContent(context),
//            //                Date = DateTime.UtcNow,
//            //                EndpointId = endpointId,
//            //                GatewayId = gatewayId,
//            //                TraceId = context.TraceIdentifier
//            //            };
//            //            ioTDataFactory.Send(data);
//            //            context.Response.StatusCode = 200;
//            //        }

//            //        await context.Response.WriteAsync(string.Empty);

//            //    }
//            //    catch (Exception ex)
//            //    {

//            //        context.Response.StatusCode = 500;
//            //        await context.Response.WriteAsync(ex.Message);
//            //    }

//            //});
//            #endregion
//        }

//        public string GetRequestContent(HttpContext context)
//        {
//            var requestContent = new StreamReader(context.Request.Body).ReadToEnd();
//            return requestContent;
//        }

//    }
//}

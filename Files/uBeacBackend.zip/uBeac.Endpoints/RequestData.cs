﻿using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using uBeac.Models;

namespace uBeac.Endpoints
{
    public class PostedData
    {
        public string TraceId { get; set; }
        public DateTime Date { get; set; }
        public string Host { get; set; }
        public int? Port { get; set; }
        public string Scheme { get; set; }
        public string ContentType { get; set; }
        public long? ContentLength { get; set; }
        public string QueryString { get; set; }
        public string Method { get; set; }
        public string Protocol { get; set; }
        public bool HasFormContentType { get; set; }
        public string Path { get; set; }
        public Dictionary<string, List<string>> Headers { get; set; }
        public string Content { get; set; }
        public string EndpointId { get; set; }
        public string FirmwareId { get; set; }
    }

    public class TraceInfo : BaseEntity
    {
        // custom properties
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public long Duration { get; set; }
        // public string Id { get; set; }
        public RequestInfo Request { get; set; }
        public ResponseInfo Response { get; set; }
        public string Error { get; set; }
        public ClientInfo Client { get; set; }
    }

    public class RequestInfo
    {
        // request properties
        public string Host { get; set; }
        public int? Port { get; set; }
        public string Scheme { get; set; }
        public string ContentType { get; set; }
        public long? ContentLength { get; set; }
        public string QueryString { get; set; }
        public string Method { get; set; }
        public string Protocol { get; set; }
        public bool HasFormContentType { get; set; }
        public string Path { get; set; }
        public Dictionary<string, List<string>> Headers { get; set; }
        public string Content { get; set; }        
    }

    public class ResponseInfo
    {
        // response properties
        public string Content { get; set; }
        public int StatusCode { get; set; }
    }

    public class ClientInfo
    {
        public string Ip { get; set; }
        public string Port { get; set; }
        public string HostName { get; set; }
        public string UserAgent { get; set; }
        public bool IsMobile { get; set; }
        public string UserEnvironment { get; set; }
    }

}

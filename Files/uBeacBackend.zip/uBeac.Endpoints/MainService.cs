﻿//using System;
//using System.Collections.Generic;

//namespace uBeac.Endpoints
//{
//    public class Gateways : Dictionary<string, Gateway>
//    {
//    }

//    public class Gateway
//    {
//        public string Id { get; set; }
//        public string Name { get; set; }
//        public Endpoint Endpoint { get; set; }
//    }

//    public class Endpoint
//    {
//        public string Id { get; set; }
//        public string Url { get; set; }
//        public string Name { get; set; }
//        public int RequestCount { get; set; }
//        public DateTime LastRequestDate { get; set; }
//    }

//    public class Endpoints : Dictionary<string, Endpoint>
//    {
//    }

//    public class MainService
//    {

//        private Gateways gateways;
//        private Endpoints endpoints;
//        private Dictionary<string, string> endpointUrls;

//        public MainService()
//        {
//            gateways = new Gateways();
//            endpoints = new Endpoints();
//            endpointUrls = new Dictionary<string, string>();

//            // predefined endpoints
//            for (int i = 0; i < 10; i++)
//            {
//                var endpoint = new Endpoint()
//                {
//                    Id = i.ToString(),
//                    Url = "e" + i.ToString(),
//                    LastRequestDate = DateTime.Now,
//                    Name = "End point " + i.ToString(),
//                    RequestCount = 0
//                };

//                endpoints.Add(endpoint.Id, endpoint);
//                endpointUrls.Add(endpoint.Url, endpoint.Id);
//            }

//            // predefined edges
//            for (int i = 0; i < 30; i++)
//            {
//                var gateway = new Gateway()
//                {
//                    Id = i.ToString(),
//                    Name = "Edge name " + i.ToString(),
//                    Endpoint = endpoints[Convert.ToInt16(i / 10).ToString()]
//                };
//                gateways.Add(i.ToString(), gateway);
//            }

//        }

//        public string GetEndpointId(string url)
//        {
//            if (!endpointUrls.ContainsKey(url))
//                return string.Empty;

//            return endpointUrls[url];
//        }


//        public string GetGatewayId(string url)
//        {
//            if (!endpointUrls.ContainsKey(url))
//                return string.Empty;
//            string endpointId = endpointUrls[url];

//            if (!gateways.ContainsKey(endpointId))
//                return string.Empty;

//            return gateways[endpointId].Id;
//        }

//    }



//}

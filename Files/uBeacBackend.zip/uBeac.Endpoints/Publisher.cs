﻿//using Newtonsoft.Json;
//using RabbitMQ.Client;
//using System;
//using System.Text;

//namespace uBeac.Endpoints
//{
//    public class Publisher<TData> : IPublisher<TData>
//    {
//        private readonly ConnectionFactory _connectionFactory;
//        private readonly IConnection _connection;
//        private readonly IModel _channel;
//        private readonly IBasicProperties _properties;

//        public Publisher()
//        {
//            _connectionFactory = new ConnectionFactory() { HostName = "localhost" };
//            _connection = _connectionFactory.CreateConnection();
//            _channel = _connection.CreateModel();
//            _channel.QueueDeclare(queue: "ednpoint_rawdata_queue", durable: true, exclusive: false, autoDelete: false, arguments: null);
//            _properties = _channel.CreateBasicProperties();
//            _properties.Persistent = true;
//        }

//        public void Send(TData data)
//        {
//            var message = JsonConvert.SerializeObject(data);
//            var body = Encoding.UTF8.GetBytes(message);
//            _channel.BasicPublish(exchange: "", routingKey: "ednpoint_rawdata_queue", basicProperties: _properties, body: body);
//        }

//        public void Dispose()
//        {
//            _connection.Close();
//            _connection.Dispose();
//        }
//    }

//    public interface IPublisher<TData> : IDisposable
//    {
//        void Send(TData data);
//    }
//}

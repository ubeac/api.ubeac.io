﻿//using MongoDB.Driver;
//using uBeac.Repositories;
//using uBeac.Repositories.MongoDB;
//using uBeac.Endpoints;

//namespace uBeacAPI.Repositories
//{
//    public class RequestDataRepository : BaseEntityRepository<TraceInfo>, IRequestDataRepository
//    {
//        public RequestDataRepository(IMongoDatabase database) : base(database)
//        {
//        }
//        protected override string CollectionName { get => "TraceInfo"; }
//        protected override string GetIdValue(TraceInfo entity) => entity.Id;                          
//    }

//    public interface IRequestDataRepository : IRepository<TraceInfo>
//    {

//    }
//}
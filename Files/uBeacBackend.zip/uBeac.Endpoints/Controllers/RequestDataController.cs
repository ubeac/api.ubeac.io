﻿//using AutoMapper;
//using Microsoft.AspNetCore.Mvc;
//using System.ComponentModel.DataAnnotations;
//using System.Threading.Tasks;
//using uBeac.Endpoints;
////using uBeac.Api;
////using uBeac.Models;
////using uBeac.Services;

//namespace uBeac.AdminApi.Controllers
//{
//    // using Result = ApiResult<Team>;

//    public class RequestDataController : Api.BaseEntityController<TraceInfo>
//    {
//        //protected readonly IMapper Mapper;        
//        private static Services.IRequestDataService _service;
//        public RequestDataController(Services.IRequestDataService service) : base(service)
//        {
//            _service = service;
//            //Mapper = mapper;
//        }

//         [HttpPut]
//        public static async Task<TraceInfo> Add(TraceInfo model)
//        {
//            return await _service.AddAsync(model);
//        }
                
//    }

//    //public class TeamInputModel
//    //{
//    //    public string Id { get; set; }

//    //    [Required]
//    //    [StringLength(50, MinimumLength = 3)]
//    //    public string Name { get; set; }

//    //    [StringLength(250)]
//    //    public string Description { get; set; }
//    //}
//}

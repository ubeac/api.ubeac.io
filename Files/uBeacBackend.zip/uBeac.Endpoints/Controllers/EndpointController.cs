﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using uBeac.Api;

namespace uBeac.Endpoints.Controllers
{

    public class EndpointController : Controller
    {
        [Route("{*url}")]
        public async Task<string> Index(string url)
        {
            var context = HttpContext;
            var request = HttpContext.Request;
            var response = HttpContext.Response;
            request.Body.Position = 0;

            var data = new PostedData()
            {
                TraceId = context.TraceIdentifier,
                Date = DateTime.UtcNow,
                Method = request.Method,
                ContentType = request.ContentType,
                ContentLength = request.ContentLength,
                Host = request.Host.Host,
                Port = request.Host.Port,
                Scheme = request.Scheme,
                QueryString = request.QueryString.ToString(),
                Protocol = request.Protocol,
                HasFormContentType = request.HasFormContentType,
                Path = request.Path.Value,
                Headers = request.Headers.ToDictionary(item => item.Key, item => item.Value.ToList()),
                Content = new StreamReader(request.Body).ReadToEnd(),
            };

            return await Task.FromResult(data.Content);

            //var traceInfo = new TraceInfo()
            //{
            //    Id =  context.TraceIdentifier,
            //    StartDate = DateTime.UtcNow,
            //    Request = AnalyzeRequest.GetRequestInfo(request),
            //    Response = new ResponseInfo()
            //    {
            //        StatusCode = response.StatusCode,
            //        Content = responseContent
            //    },
            //    Client = AnalyzeRequest.GetClientInfo(request)
            //};

            //context.Items.Add("TraceInfo", traceInfo);

            //try
            //{
            //    using (var memStream = new MemoryStream())
            //    {
            //        context.Response.Body = memStream;

            //        //await _next(context);

            //        memStream.Position = 0;
            //        responseContent = new StreamReader(memStream).ReadToEnd();

            //        memStream.Position = 0;
            //        await memStream.CopyToAsync(originalBody);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    error = ex.Message;
            //}

            //try
            //{
            //    context.Response.Body = originalBody;
            //}
            //catch (Exception ex)
            //{
            //    error += ex.Message;
            //}

            //traceInfo.EndDate = DateTime.UtcNow;
            //traceInfo.Error = error;
            //traceInfo.Duration = (traceInfo.EndDate - traceInfo.StartDate).Ticks;
            //await requestService.AddAsync(traceInfo);
            //await AdminApi.Controllers.RequestDataController.Add(traceInfo);
            //publisher.Send(data);
            

        }
    }
}

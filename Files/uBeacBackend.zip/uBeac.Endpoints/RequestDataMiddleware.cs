﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Internal;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;


namespace uBeac.Endpoints
{
    public class RequestDataMiddleware
    {
        private readonly RequestDelegate _next;
        // private Services.IRequestDataService _service;

        public RequestDataMiddleware(RequestDelegate next) 
        {
            _next = next;            
        }

        public async Task Invoke(HttpContext context)
        {
            context.Request.EnableRewind();
            var request = context.Request;
            var requestContent = new StreamReader(request.Body).ReadToEnd();
            request.Body.Position = 0;
            var response = context.Response;
            var responseContent = string.Empty;
            var error = string.Empty;
            Stream originalBody = context.Response.Body;

            var traceInfo = new TraceInfo()
            {
                Id = context.TraceIdentifier,
                StartDate = DateTime.UtcNow,
                Request = new RequestInfo()
                {
                    Method = request.Method,
                    ContentType = request.ContentType,
                    ContentLength = request.ContentLength,
                    Host = request.Host.Host,
                    Port = request.Host.Port,
                    Scheme = request.Scheme,
                    QueryString = request.QueryString.ToString(),
                    Protocol = request.Protocol,
                    HasFormContentType = request.HasFormContentType,
                    Path = request.Path.Value,
                    //Headers = request.Headers.ToDictionary(item => item.Key, item => item.Value),
                    Headers = request.Headers.ToDictionary(item => item.Key, item => item.Value.ToList()),
                    Content = requestContent,
                },
                Response = new ResponseInfo()
                {
                    StatusCode = response.StatusCode,
                    Content = responseContent
                },
                //Client = new ClientInfo()
                //{
                //    Ip = request.HttpContext.Connection.RemoteIpAddress.ToString(),
                //    Port = request.HttpContext.Connection.RemotePort.ToString(),
                //    HostName = GetComputerName(request.HttpContext.Connection.RemoteIpAddress.ToString()),
                //    UserAgent = request.Headers["User-Agent"],
                //    IsMobile = IsMobile(request),
                //    UserEnvironment = GetUserEnvironment(request),
                //}
            };

            context.Items.Add("TraceInfo", traceInfo);

            try
            {
                using (var memStream = new MemoryStream())
                {
                    context.Response.Body = memStream;

                    await _next(context);

                    memStream.Position = 0;
                    responseContent = new StreamReader(memStream).ReadToEnd();

                    memStream.Position = 0;
                    await memStream.CopyToAsync(originalBody);
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }

            try
            {
                context.Response.Body = originalBody;
            }
            catch (Exception ex)
            {
                error += ex.Message;
            }

            traceInfo.EndDate = DateTime.UtcNow;
            traceInfo.Error = error;
            traceInfo.Duration = (traceInfo.EndDate - traceInfo.StartDate).Ticks;
            
            //await AdminApi.Controllers.RequestDataController.Add(traceInfo);
        }
        
    }
    
    public static class HttpContextExtensions
    {
        public static TraceInfo GetRequestData(this HttpContext context)
        {
            if (context.Items.ContainsKey("TraceInfo"))
            {
                return (TraceInfo)context.Items["TraceInfo"];
            }
            else
            {
                return null;
            }
        }
    }

}

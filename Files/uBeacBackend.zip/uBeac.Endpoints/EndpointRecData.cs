﻿using System;

namespace uBeac.Endpoints
{
    public class EndpointRecData
    {
        public string TraceId { get; set; }
        public DateTime Date { get; set; }
        public string Data { get; set; }
        public string FirmwareId { get; set; }
        public string EndpointId { get; set; }
    }
}

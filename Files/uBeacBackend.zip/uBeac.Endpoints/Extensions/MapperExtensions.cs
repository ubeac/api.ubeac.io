﻿using AutoMapper;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class MapperExtensions
    {
        public static IServiceCollection AddMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(cfg =>
            {
                //cfg.CreateMap<UserInputModel, User>();
            });

            return services;
        }
    }
}

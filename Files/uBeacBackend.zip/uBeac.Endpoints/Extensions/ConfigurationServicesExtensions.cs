﻿using Microsoft.Extensions.Configuration;
using uBeac.Repositories;
using uBeac.Services;
using uBeacAPI.Repositories;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class ConfigurationServicesExtensions
    {

        public static IServiceCollection AddRepositories(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddDatabase(configuration);
            //services.AddScoped<IRequestDataRepository, RequestDataRepository>();
            //services.AddScoped<IEndpointRepository, EndpointRepository>();
            //services.AddScoped<IGatewayRepository, GatewayRepository>();
            //services.AddScoped<IManufacturerRepository, ManufacturerRepository>();
            //services.AddScoped<IGatewayFirmwareRepository, GatewayFirmwareRepository>();

            return services;
        }
        
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            //services.AddScoped<IRequestDataService, RequestDataService>();
            //services.AddScoped<IEndpointService, EndpointService>();

            return services;
        }

        //public static IServiceCollection AddMapper(this IServiceCollection services)
        //{
        //    services.AddAutoMapper(cfg =>
        //    {
        //        cfg.CreateMap<ManufacturerInputModel, Manufacturer>();
        //        cfg.CreateMap<GatewayInputModel, Gateway>();
        //        cfg.CreateMap<GatewayFirmwareInputModel, GatewayFirmware>();
        //        cfg.CreateMap<TeamInputModel, Team>();
        //        cfg.CreateMap<EndpointInputModel, Endpoint>();
        //    });

        //    return services;
        //}

    }

}


﻿//using System.Threading;
//using System.Threading.Tasks;
//using uBeac.Endpoints;
//using uBeacAPI.Repositories;

//namespace uBeac.Services
//{
//    public class RequestDataService : BaseEntityService<TraceInfo>, IRequestDataService
//    {
//        private IRequestDataRepository _repository;
//        public RequestDataService(IRequestDataRepository repository) : base(repository)
//        {
//            _repository = repository;
//        }

//        public override async Task<TraceInfo> AddAsync(TraceInfo model, CancellationToken cancellationToken = default(CancellationToken))
//        {
//            ThrowIfDisposed();
//            cancellationToken.ThrowIfCancellationRequested();

//            return await base.AddAsync(model);
//        }
       
//    }

//    public interface IRequestDataService : IBaseEntityService<TraceInfo>
//    {
        
//    }
//}

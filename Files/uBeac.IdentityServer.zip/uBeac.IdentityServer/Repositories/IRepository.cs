﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories
{
    public interface IRepository<TEntity> :
        IDisposable
        where TEntity : class
    {
        Task<TEntity> InsertAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> UpdateAsync(TEntity entity, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> GetByIdAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<TEntity> DeleteAsync(string id, CancellationToken cancellationToken = default(CancellationToken));
        Task<IEnumerable<TEntity>> GetAllAsync(CancellationToken cancellationToken = default(CancellationToken));
        IQueryable<TEntity> AsQueryableAsync(CancellationToken cancellationToken = default(CancellationToken));
    }

    public interface IUserRepository<TUser> :
    IRepository<TUser>
    where TUser : User
    {
        Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken = default(CancellationToken));
        Task<TUser> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<TUser>> GetUsersForClaimAsync(string claimType, string claimValue, CancellationToken cancellationToken = default(CancellationToken));
        Task<TUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken = default(CancellationToken));
        Task<IList<TUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken = default(CancellationToken));
    }

    public interface IRoleRepository<TRole> :
    IRepository<TRole>
    where TRole : Role
    {
        IQueryable<TRole> AsQueryableAsync();
        Task<TRole> GetByNameAsync(string name, CancellationToken cancellationToken = default(CancellationToken));

    }

}

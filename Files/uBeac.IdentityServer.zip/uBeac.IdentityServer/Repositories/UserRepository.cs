﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MongoDB.Driver;
using uBeac.IdentityServer.Models;

namespace uBeac.IdentityServer.Repositories.MongoDB
{
    public class UserRepository<TUser> :
        MongoGenericRepository<TUser>,
        IUserRepository<TUser>
        where TUser : User
    {

        public UserRepository(IMongoDatabase database) : base(database)
        {
        }

        protected override string CollectionName => "Users";

        public async Task<TUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            normalizedEmail.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TUser>.Filter.Eq(x => x.NormalizedEmail, normalizedEmail);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public async Task<TUser> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            loginProvider.ThrowIfNull();
            providerKey.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TUser>.Filter.ElemMatch(x => x.Logins, x => x.LoginProvider == loginProvider && x.ProviderKey == providerKey);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public async Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            normalizedUserName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TUser>.Filter.Eq(x => x.NormalizedUserName, normalizedUserName);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);
            return result.FirstOrDefault();
        }

        public async Task<IList<TUser>> GetUsersForClaimAsync(string claimType, string claimValue, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            claimType.ThrowIfNull();
            claimValue.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TUser>.Filter.ElemMatch(x => x.Claims, x => x.ClaimValue == claimValue && x.ClaimType == claimType);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);

            return result.ToList();
        }

        public async Task<IList<TUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var query = Builders<TUser>.Filter.ElemMatch(x => x.Roles, x => x == roleName);
            var result = await Collection.FindAsync(query, cancellationToken: cancellationToken).ConfigureAwait(false);

            return (IList<TUser>)result.ToListAsync();

        }

        protected override string GetIdValue(TUser entity) => entity.Id;

        protected override void SetIdValue(TUser entity)
        {
            // do nothing
        }
    }
}

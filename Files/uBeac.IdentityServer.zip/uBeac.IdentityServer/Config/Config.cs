﻿using IdentityServer4.Models;
using System.Collections.Generic;

namespace uBeac.IdentityServer
{
    public class Config
    {
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(),
                new IdentityResources.Profile(),
                new IdentityResources.Email(),
                new IdentityResources.Phone(),
                new IdentityResources.Address(),
                new IdentityResource("Roles","Roles for the user", new List<string> { "role" })
            };
        }
    }

}

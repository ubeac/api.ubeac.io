﻿using System.Collections.Generic;

namespace uBeac.IdentityServer
{
    public class IdentityServerConfig
    {
        public string ConnectionStringName { get; set; }
        public Password IdentityOptions { get; set; }

        public string GoogleClientId { get; set; }
        public string GoogleClientSecret { get; set; }
        public string MicrosoftClientId { get; set; }
        public string MicrosoftClientSecret { get; set; }
        public string TwitterConsumerKey { get; set; }
        public string TwitterConsumerSecret { get; set; }
        public string FacebookAppId { get; set; }
        public string FacebookAppSecret { get; set; }
        public string GitHubClientId { get; set; }
        public string GitHubClientSecret { get; set; }
        public string LinedInClientId { get; set; }
        public string LinedInClientSecret { get; set; }
        public List<Client> Clients { get; set; }
        public List<string> ApiResources { get; set; }

        public class Password
        {
            public bool RequireDigit { get; set; }
            public int RequiredLength { get; set; }
            public bool RequireNonAlphanumeric { get; set; }
            public bool RequireUppercase { get; set; }
            public bool RequireLowercase { get; set; }
            public bool LockoutAllowedForNewUsers { get; set; }
            public int LockoutMaxFailedAccessAttempts { get; set; }
            public int LockoutDefaultLockoutTimeSpanMinutes { get; set; }
        }

        public class Client
        {
            public string ClientId { get; set; }
            public string ClientName { get; set; }
            public List<string> ClientSecrets { get; set; }
            public string AllowedGrantTypes { get; set; }
            public bool AllowAccessTokensViaBrowser { get; set; }
            public bool RequireConsent { get; set; }
            public List<string> RedirectUris { get; set; }
            public List<string> PostLogoutRedirectUris { get; set; }
            public List<string> AllowedCorsOrigins { get; set; }
            public string AllowedScopes { get; set; }
        }

    }
}

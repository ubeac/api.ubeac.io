﻿using IdentityServer4.Models;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MongoDB.Driver;
using System;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
using uBeac.IdentityServer.Controllers;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Repositories;
using uBeac.IdentityServer.Repositories.MongoDB;
using uBeac.IdentityServer.Services;

namespace uBeac.IdentityServer
{
    public static class IdentityExtensions
    {

        public static void ThrowIfNull(this object source)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
        }

        public static void ThrowIfNull(this string source)
        {
            if (string.IsNullOrEmpty(source)) throw new ArgumentNullException(nameof(source));
        }

        public static string EmailConfirmationLink(this IUrlHelper urlHelper, string userId, string code, string scheme)
        {
            return urlHelper.Action(
                action: nameof(AccountController.ConfirmEmail),
                controller: "Account",
                values: new { userId, code },
                protocol: scheme);
        }

        public static string ResetPasswordCallbackLink(this IUrlHelper urlHelper, string userId, string code, string scheme)
        {
            return urlHelper.Action(
                action: nameof(AccountController.ResetPassword),
                controller: "Account",
                values: new { userId, code },
                protocol: scheme);
        }

        public static Task SendEmailConfirmationAsync(this IEmailSender emailSender, string email, string link)
        {
            return emailSender.SendEmailAsync(email, "Confirm your email",
                $"Please confirm your account by clicking this link: <a href='{HtmlEncoder.Default.Encode(link)}'>link</a>");
        }

        public static IServiceCollection AddIdentity(this IServiceCollection services, IConfiguration configuration, IdentityServerConfig identityServerConfig, AppConfig appConfig, IHostingEnvironment env)
        {
            var setupAction = new Action<IdentityOptions>(options =>
            {
                // example of setting options
                options.Tokens.ChangePhoneNumberTokenProvider = "Phone";
                // Password settings.
                options.Password.RequireDigit = identityServerConfig.IdentityOptions.RequireDigit;
                options.Password.RequiredLength = identityServerConfig.IdentityOptions.RequiredLength;
                options.Password.RequireNonAlphanumeric = identityServerConfig.IdentityOptions.RequireNonAlphanumeric;
                options.Password.RequireUppercase = identityServerConfig.IdentityOptions.RequireUppercase;
                options.Password.RequireLowercase = identityServerConfig.IdentityOptions.RequireLowercase;
                // Lockout settings.
                options.Lockout.AllowedForNewUsers = identityServerConfig.IdentityOptions.LockoutAllowedForNewUsers;
                options.Lockout.MaxFailedAccessAttempts = identityServerConfig.IdentityOptions.LockoutMaxFailedAccessAttempts;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(identityServerConfig.IdentityOptions.LockoutDefaultLockoutTimeSpanMinutes);
            });

            services.AddSingleton(provider =>
            {
                var mongoUrl = new MongoUrl(configuration.GetConnectionString(identityServerConfig.ConnectionStringName));
                var client = new MongoClient(mongoUrl);
                return client.GetDatabase(mongoUrl.DatabaseName);
            });

            services.AddScoped<IUserRepository<User>, UserRepository<User>>();
            services.AddScoped<IRoleRepository<Role>, RoleRepository<Role>>();

            services.AddScoped<IUserStore<User>, UserService<User>>();
            services.AddScoped<IRoleStore<Role>, RoleService<Role>>();
            services.AddScoped<IProfileService, ProfileService>();
            services.AddScoped<IEmailSender, EmailSender>();

            services.AddIdentity<User, Role>(setupAction)
                .AddUserStore<UserService<User>>()
                .AddDefaultTokenProviders();

            if (env.IsProduction())
            {
                services.AddAuthentication()
                                .AddGoogle("Google", options =>
                                {
                                    options.ClientId = identityServerConfig.GoogleClientId;
                                    options.ClientSecret = identityServerConfig.GoogleClientSecret;
                                })
                                .AddMicrosoftAccount("Microsoft", options =>
                                {
                                    options.ClientId = identityServerConfig.MicrosoftClientId;
                                    options.ClientSecret = identityServerConfig.MicrosoftClientSecret;
                                })
                                .AddTwitter("Twitter", option =>
                                {
                                    option.ConsumerKey = identityServerConfig.TwitterConsumerKey;
                                    option.ConsumerSecret = identityServerConfig.TwitterConsumerSecret;
                                })
                                .AddFacebook("Facebook", options =>
                                {
                                    options.AppId = identityServerConfig.FacebookAppId;
                                    options.AppSecret = identityServerConfig.FacebookAppSecret;
                                })
                                .AddGitHub(options =>
                                {
                                    options.ClientId = identityServerConfig.GitHubClientId;
                                    options.ClientSecret = identityServerConfig.GitHubClientSecret;

                                }).AddLinkedIn("LinedIn", options =>
                                {
                                    options.ClientId = identityServerConfig.LinedInClientId;
                                    options.ClientSecret = identityServerConfig.LinedInClientSecret;
                                });
            }

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddIdentityServerAuthentication(options =>
                {
                    options.Authority = appConfig.Url;
                    options.RequireHttpsMetadata = false;
                    options.ApiName = appConfig.Name;
                });

            services.AddIdentityServer()
                .AddDeveloperSigningCredential()
                .AddInMemoryPersistedGrants()
                .AddInMemoryIdentityResources(Config.GetIdentityResources())
                .AddInMemoryApiResources(identityServerConfig.ApiResources.Select(item => new ApiResource(item)))
                .AddInMemoryClients(identityServerConfig.Clients.Select(item => GetClient(item)))
                .AddAspNetIdentity<User>()
                .AddProfileService<ProfileService>();

            return services;

        }

        internal static Client GetClient(IdentityServerConfig.Client client)
        {
            var result = new Client()
            {
                ClientId = client.ClientId,
                ClientName = client.ClientName,
                AllowedGrantTypes = client.AllowedGrantTypes.Split(" "),
                AllowAccessTokensViaBrowser = client.AllowAccessTokensViaBrowser,
                RequireConsent = client.RequireConsent,
                RedirectUris = client.RedirectUris,
                PostLogoutRedirectUris = client.PostLogoutRedirectUris,
                AllowedCorsOrigins = client.AllowedCorsOrigins,
                AllowedScopes = client.AllowedScopes.Split(" ")
            };

            if (client.ClientSecrets != null)
            {
                client.ClientSecrets.ForEach(secret => result.ClientSecrets.Add(new Secret(secret.Sha256())));
            }
            return result;

        }

        public static IApplicationBuilder UseJWT(this IApplicationBuilder app)
        {

            app.Use(async (context, next) =>
            {
                if (!context.User.Identity.IsAuthenticated)
                {
                    var result = await context.AuthenticateAsync(JwtBearerDefaults.AuthenticationScheme);
                    if (result?.Principal != null)
                    {
                        context.User = result.Principal;
                    }
                }

                await next.Invoke();
            });

            return app;
        }

    }
}

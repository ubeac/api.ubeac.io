﻿using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace uBeac.IdentityServer.Models
{
    public class Role : IdentityRole
    {
        public List<RoleClaim> Claims { get; set; }
        public bool IsDeleted { get; set; } 

        public Role()
        {
            IsDeleted = false;
            Claims = new List<RoleClaim>();
        }

    }

    public class RoleClaim : IdentityRoleClaim<string>
    {
    }
}

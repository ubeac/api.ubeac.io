﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using uBeac.IdentityServer.Controllers;

namespace uBeac.IdentityServer
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public IHostingEnvironment Environment;
        public AppConfig AppConfig;
        public IdentityServerConfig IdentityServerConfig;

        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            Environment = env;
            AppConfig = new AppConfig();
            configuration.Bind("AppConfig", AppConfig);
            IdentityServerConfig = new IdentityServerConfig();
            configuration.Bind("IdentityServerConfig", IdentityServerConfig);
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services
              .AddIdentity(Configuration, IdentityServerConfig, AppConfig, Environment)
              .AddSwaggerGen(c =>
              {
                  c.SwaggerDoc(AppConfig.Version, new Info { Title = AppConfig.Name, Version = AppConfig.Version });
              })
              .AddResponseCompression()
              .AddCors(options =>
              {
                  options.AddPolicy("AppConfigCors", policy =>
                  {
                      foreach (string item in AppConfig.CorsOrigins)
                      {
                          policy.WithOrigins(item).AllowAnyHeader().AllowAnyMethod();
                      }
                  });
              })
              .AddMvc();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {

            app
                .UseMiddleware(typeof(ExceptionHandlingMiddleware))
                .UseResponseCompression()
                .UseCors("AppConfigCors")
                .UseStaticFiles()
                .UseIdentityServer()
                .UseJWT()
                .UseSwagger()
                .UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/" + AppConfig.Version + "/swagger.json", AppConfig.Name);
                })
                .UseMvc(routes =>
                {
                    routes.MapRoute(
                        name: "default",
                        template: "{controller=Home}/{action=Index}/{id?}");
                });
        }
    }
}

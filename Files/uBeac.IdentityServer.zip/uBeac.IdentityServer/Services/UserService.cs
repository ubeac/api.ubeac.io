﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Repositories;

namespace uBeac.IdentityServer.Services
{
    public class UserService<TUser> :
        IUserStore<TUser>,
        IUserLoginStore<TUser>,
        IUserClaimStore<TUser>,
        IUserPasswordStore<TUser>,
        IUserSecurityStampStore<TUser>,
        IUserTwoFactorStore<TUser>,
        IUserEmailStore<TUser>,
        IUserLockoutStore<TUser>,
        IUserPhoneNumberStore<TUser>,
        IUserAuthenticatorKeyStore<TUser>,
        IUserAuthenticationTokenStore<TUser>,
        IUserTwoFactorRecoveryCodeStore<TUser>,
        IUserRoleStore<TUser>
        where TUser : User
    {

        private IUserRepository<TUser> _repository;
        private bool _disposed;

        public UserService(IUserRepository<TUser> repository)
        {
            _disposed = false;
            repository.ThrowIfNull();
            _repository = repository;
        }

        public void Dispose()
        {
            _disposed = true;
            _repository.Dispose();
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        #region IUserStore Implementation

        public async Task<IdentityResult> CreateAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            await _repository.InsertAsync(user, cancellationToken);

            return IdentityResult.Success;
        }

        public async Task<IdentityResult> DeleteAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.IsDeleted = true;

            await _repository.UpdateAsync(user, cancellationToken);

            return IdentityResult.Success;
        }

        public async Task<TUser> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            userId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TUser user = await _repository.GetByIdAsync(userId, cancellationToken);

            if (user != null && user.IsDeleted) return null;

            return user;

        }

        public async Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            normalizedUserName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TUser user = await _repository.FindByNameAsync(normalizedUserName, cancellationToken);

            if (user != null && user.IsDeleted) return null;

            return user;

        }

        public Task<string> GetNormalizedUserNameAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.NormalizedUserName);
        }

        public Task<string> GetUserIdAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.Id);
        }

        public Task<string> GetUserNameAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.UserName);
        }

        public Task SetNormalizedUserNameAsync(TUser user, string normalizedName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            normalizedName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.NormalizedUserName = normalizedName;

            return Task.FromResult(0);
        }

        public Task SetUserNameAsync(TUser user, string userName, CancellationToken cancellationToken)
        {
            throw new NotSupportedException("Changing the username is not supported.");
        }

        public async Task<IdentityResult> UpdateAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            await _repository.UpdateAsync(user, cancellationToken);

            return IdentityResult.Success;

        }

        #endregion IUserStore Implementation

        #region IUserLoginStore Implementation
        public Task AddLoginAsync(TUser user, UserLoginInfo login, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            login.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            // NOTE: Not the best way to ensure uniquness.
            if (user.Logins.Any(x => x.Equals(login)))
            {
                throw new InvalidOperationException("Login already exists.");
            }

            var newUserLogin = new UserLogin()
            {
                LoginProvider = login.LoginProvider,
                ProviderDisplayName = login.ProviderDisplayName,
                ProviderKey = login.ProviderKey,
                UserId = user.Id
            };

            user.Logins.Add(newUserLogin);

            return Task.FromResult(0);
        }

        public Task RemoveLoginAsync(TUser user, string loginProvider, string providerKey, CancellationToken cancellationToken)
        {

            ThrowIfDisposed();
            user.ThrowIfNull();
            loginProvider.ThrowIfNull();
            providerKey.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var login = new UserLoginInfo(loginProvider, providerKey, string.Empty);
            var loginToRemove = user.Logins.FirstOrDefault(x => x.Equals(login));

            if (loginToRemove != null) user.Logins.Remove(loginToRemove);

            return Task.FromResult(0);

        }

        public Task<IList<UserLoginInfo>> GetLoginsAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var logins = user.Logins.Select(login =>
                new UserLoginInfo(login.LoginProvider, login.ProviderKey, login.ProviderDisplayName));

            return Task.FromResult<IList<UserLoginInfo>>(logins.ToList());
        }

        public async Task<TUser> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            loginProvider.ThrowIfNull();
            providerKey.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TUser user = await _repository.FindByLoginAsync(loginProvider, providerKey);
            return user != null && user.IsDeleted ? null : user;

        }

        #endregion IUserLoginStore Implementation

        #region IUserClaimStore Implementation

        public Task<IList<Claim>> GetClaimsAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var claims = user.Claims.Select(clm => new Claim(clm.ClaimType, clm.ClaimValue)).ToList();

            return Task.FromResult<IList<Claim>>(claims);
        }

        public Task AddClaimsAsync(TUser user, IEnumerable<Claim> claims, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            claims.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            foreach (var claim in claims)
            {
                var newUserClaim = new UserClaim() { UserId = user.Id };
                newUserClaim.InitializeFromClaim(claim);
                user.Claims.Add(newUserClaim);
            }

            return Task.FromResult(0);
        }

        public Task ReplaceClaimAsync(TUser user, Claim claim, Claim newClaim, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            claim.ThrowIfNull();
            newClaim.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var oldUserClaim = (from p in user.Claims where p.UserId == user.Id && p.ClaimType == claim.Type && p.ClaimValue == claim.Value select p).SingleOrDefault();

            if (oldUserClaim != null) user.Claims.Remove(oldUserClaim);

            var newUserClaim = new UserClaim() { UserId = user.Id };
            newUserClaim.InitializeFromClaim(claim);
            user.Claims.Add(newUserClaim);

            return Task.FromResult(0);
        }

        public Task RemoveClaimsAsync(TUser user, IEnumerable<Claim> claims, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            claims.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            foreach (var claim in claims)
            {
                var oldUserClaim = (from p in user.Claims where p.UserId == user.Id && p.ClaimType == claim.Type && p.ClaimValue == claim.Value select p).SingleOrDefault();
                if (oldUserClaim != null) user.Claims.Remove(oldUserClaim);
            }

            return Task.FromResult(0);
        }

        public async Task<IList<TUser>> GetUsersForClaimAsync(Claim claim, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            claim.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            IList<TUser> users = await _repository.GetUsersForClaimAsync(claim.Type, claim.Value, cancellationToken);

            return users;
        }

        #endregion IUserClaimStore Implementation

        #region IUserPasswordStore Implementation

        public Task SetPasswordHashAsync(TUser user, string passwordHash, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.PasswordHash = passwordHash;

            return Task.FromResult(0);
        }

        public Task<string> GetPasswordHashAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.PasswordHash);
        }

        public Task<bool> HasPasswordAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.PasswordHash != null);
        }

        #endregion IUserPasswordStore Implementation

        #region IUserSecurityStampStore Implementation

        public Task SetSecurityStampAsync(TUser user, string stamp, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            stamp.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.SecurityStamp = stamp;

            return Task.FromResult(0);
        }

        public Task<string> GetSecurityStampAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.SecurityStamp);
        }

        #endregion IUserSecurityStampStore Implementation

        #region IUserTwoFactorStore Implementation

        public Task SetTwoFactorEnabledAsync(TUser user, bool enabled, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.TwoFactorEnabled = enabled;

            return Task.FromResult(0);

        }

        public Task<bool> GetTwoFactorEnabledAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.TwoFactorEnabled);
        }

        #endregion IUserTwoFactorStore Implementation

        #region IUserEmailStore Implementation

        public Task SetEmailAsync(TUser user, string email, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            email.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.Email = email;

            return Task.FromResult(0);
        }

        public Task<string> GetEmailAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var email = (string.IsNullOrEmpty(user.Email) ? string.Empty : user.Email);

            return Task.FromResult(user.Email);
        }

        public Task<bool> GetEmailConfirmedAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrEmpty(user.Email)) throw new InvalidOperationException("Cannot get the confirmation status of the e-mail since the user doesn't have an e-mail.");

            return Task.FromResult(user.EmailConfirmed);
        }

        public Task SetEmailConfirmedAsync(TUser user, bool confirmed, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrEmpty(user.Email)) throw new InvalidOperationException("Cannot get the confirmation status of the e-mail since the user doesn't have an e-mail.");

            user.EmailConfirmed = confirmed;

            return Task.FromResult(0);
        }

        public async Task<TUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken)
        {

            ThrowIfDisposed();
            normalizedEmail.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TUser user = await _repository.FindByEmailAsync(normalizedEmail, cancellationToken);

            return user;
        }

        public Task<string> GetNormalizedEmailAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var normalizedEmail = (string.IsNullOrEmpty(user.Email) ? string.Empty : user.Email);

            return Task.FromResult(normalizedEmail);
        }

        public Task SetNormalizedEmailAsync(TUser user, string normalizedEmail, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            normalizedEmail.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            // This method can be called even if user doesn't have an e-mail.
            // Act cool in this case and gracefully handle.
            // More info: https://github.com/aspnet/Identity/issues/645

            if (!string.IsNullOrEmpty(normalizedEmail) && !string.IsNullOrEmpty(user.Email))
            {
                user.NormalizedEmail = normalizedEmail;
            }

            return Task.FromResult(0);
        }

        #endregion IUserEmailStore Implementation

        #region IUserLockoutStore Implementation

        public Task<DateTimeOffset?> GetLockoutEndDateAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.LockoutEnd);

        }

        public Task SetLockoutEndDateAsync(TUser user, DateTimeOffset? lockoutEnd, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.LockoutEnd = lockoutEnd;

            return Task.FromResult(0);
        }

        public async Task<int> IncrementAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var oldUser = await _repository.GetByIdAsync(user.Id);
            oldUser.AccessFailedCount += 1;
            await _repository.UpdateAsync(oldUser);

            return oldUser.AccessFailedCount;
        }

        public Task ResetAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.AccessFailedCount = 0;

            return Task.FromResult(0);
        }

        public Task<int> GetAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.AccessFailedCount);
        }

        public Task<bool> GetLockoutEnabledAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.LockoutEnabled);
        }

        public Task SetLockoutEnabledAsync(TUser user, bool enabled, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.LockoutEnabled = enabled;

            return Task.FromResult(0);
        }

        #endregion IUserLockoutStore Implementation

        #region IUserPhoneNumberStore Implementation

        public Task SetPhoneNumberAsync(TUser user, string phoneNumber, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            phoneNumber.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.PhoneNumber = phoneNumber;

            return Task.FromResult(0);
        }

        public Task<string> GetPhoneNumberAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.PhoneNumber);
        }

        public Task<bool> GetPhoneNumberConfirmedAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrEmpty(user.PhoneNumber)) throw new InvalidOperationException("Cannot get the confirmation status of the phone number since the user doesn't have a phone number.");

            return Task.FromResult(user.PhoneNumberConfirmed);
        }

        public Task SetPhoneNumberConfirmedAsync(TUser user, bool confirmed, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            if (string.IsNullOrEmpty(user.PhoneNumber)) throw new InvalidOperationException("Cannot set the confirmation status of the phone number since the user doesn't have a phone number.");

            user.PhoneNumberConfirmed = confirmed;

            return Task.FromResult(0);
        }


        #endregion IUserPhoneNumberStore Implementation

        #region IUserAuthenticatorKeyStore Implementation

        public Task SetAuthenticatorKeyAsync(TUser user, string key, CancellationToken cancellationToken)
        {

            ThrowIfDisposed();
            user.ThrowIfNull();
            key.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return SetTokenAsync(user, Constants.INTERNAL_LOGIN_PROVIDER_NAME, Constants.AUTHENTICATOR_KEY_TOKEN_NAME, key, cancellationToken);

        }

        public Task<string> GetAuthenticatorKeyAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested(); if (user is null) throw new ArgumentNullException(nameof(user));

            return GetTokenAsync(user, Constants.INTERNAL_LOGIN_PROVIDER_NAME, Constants.AUTHENTICATOR_KEY_TOKEN_NAME, cancellationToken);
        }

        #endregion IUserAuthenticatorKeyStore Implementation

        #region IUserAuthenticationTokenStore Implementation
        public Task SetTokenAsync(TUser user, string loginProvider, string name, string value, CancellationToken cancellationToken)
        {

            ThrowIfDisposed();
            user.ThrowIfNull();
            loginProvider.ThrowIfNull();
            name.ThrowIfNull();
            value.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var token = user.Tokens.SingleOrDefault(l => l.Name == name && l.LoginProvider == loginProvider && l.UserId == user.Id);
            if (token != null)
            {
                token.Value = value;
            }
            else
            {
                user.Tokens.Add(new UserToken
                {
                    UserId = user.Id,
                    LoginProvider = loginProvider,
                    Name = name,
                    Value = value
                });
            }
            return Task.FromResult(0);
        }

        public Task RemoveTokenAsync(TUser user, string loginProvider, string name, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            loginProvider.ThrowIfNull();
            name.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var token = user.Tokens.SingleOrDefault(l => l.Name == name && l.LoginProvider == loginProvider && l.UserId == user.Id);

            if (token != null) user.Tokens.Remove(token);

            return Task.FromResult(0);
        }

        public Task<string> GetTokenAsync(TUser user, string loginProvider, string name, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            loginProvider.ThrowIfNull();
            name.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var token = user.Tokens.SingleOrDefault(l => l.Name == name && l.LoginProvider == loginProvider && l.UserId == user.Id);
            return Task.FromResult(token?.Value);
        }

        #endregion IUserAuthenticationTokenStore Implementation

        #region IUserTwoFactorRecoveryCodeStore Implementation

        public Task ReplaceCodesAsync(TUser user, IEnumerable<string> recoveryCodes, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            recoveryCodes.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var mergedCodes = string.Join(";", recoveryCodes);
            return SetTokenAsync(user, Constants.INTERNAL_LOGIN_PROVIDER_NAME, Constants.RECOVERY_CODE_TOKEN_NAME, mergedCodes, cancellationToken);
        }

        public async Task<bool> RedeemCodeAsync(TUser user, string code, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            code.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var mergedCodes = await GetTokenAsync(user, Constants.INTERNAL_LOGIN_PROVIDER_NAME, Constants.RECOVERY_CODE_TOKEN_NAME, cancellationToken) ?? "";
            var splitCodes = mergedCodes.Split(';');
            if (splitCodes.Contains(code))
            {
                var updatedCodes = new List<string>(splitCodes.Where(s => s != code));
                await ReplaceCodesAsync(user, updatedCodes, cancellationToken);
                return true;
            }
            return false;
        }

        public async Task<int> CountCodesAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            var mergedCodes = await GetTokenAsync(user, Constants.INTERNAL_LOGIN_PROVIDER_NAME, Constants.RECOVERY_CODE_TOKEN_NAME, cancellationToken) ?? "";
            if (mergedCodes.Length > 0)
            {
                return mergedCodes.Split(';').Length;
            }
            return 0;
        }

        #endregion IUserTwoFactorRecoveryCodeStore Implementation

        #region IUserRoleStore Implementation

        public Task AddToRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            if (!user.Roles.Contains(roleName)) user.Roles.Add(roleName);

            return Task.FromResult(0);

        }

        public Task RemoveFromRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            user.Roles.Remove(roleName);

            return Task.FromResult(0);
        }

        public Task<IList<string>> GetRolesAsync(TUser user, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            IList<string> roles = user.Roles;
            return Task.FromResult(roles);

        }

        public Task<bool> IsInRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            user.ThrowIfNull();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(user.Roles.Contains(roleName));
        }

        public async Task<IList<TUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return await _repository.GetUsersInRoleAsync(roleName, cancellationToken);
        }

        #endregion IUserRoleStore Implementation
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Repositories;

namespace uBeac.IdentityServer.Services
{
    public class RoleService<TRole> :
        IQueryableRoleStore<TRole>,
        IRoleClaimStore<TRole>
        where TRole : Role
    {

        private IRoleRepository<TRole> _repository;
        private bool _disposed;

        public RoleService(IRoleRepository<TRole> repository)
        {
            _disposed = false;
            repository.ThrowIfNull();
            _repository = repository;
        }

        #region IRoleStore Implementation

        public IQueryable<TRole> Roles => _repository.AsQueryableAsync();

        public async Task<IdentityResult> CreateAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            await _repository.InsertAsync(role, cancellationToken);
            return IdentityResult.Success;
        }

        public async Task<IdentityResult> DeleteAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            role.IsDeleted = true;
            await _repository.UpdateAsync(role, cancellationToken);

            return IdentityResult.Success;
        }

        public async Task<TRole> FindByIdAsync(string roleId, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            roleId.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TRole role = await _repository.GetByIdAsync(roleId);

            return role != null && role.IsDeleted ? null : role;

        }

        public async Task<TRole> FindByNameAsync(string normalizedRoleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            normalizedRoleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TRole role = await _repository.GetByNameAsync(normalizedRoleName);

            return role != null && role.IsDeleted ? null : role;

        }

        public Task<string> GetNormalizedRoleNameAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(role.NormalizedName);
        }

        public Task<string> GetRoleIdAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(role.Id);
        }

        public Task<string> GetRoleNameAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return Task.FromResult(role.Name);
        }

        public Task SetNormalizedRoleNameAsync(TRole role, string normalizedName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            normalizedName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            role.NormalizedName = normalizedName;

            return Task.FromResult(0);

        }

        public Task SetRoleNameAsync(TRole role, string roleName, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            roleName.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            role.Name = roleName;

            return Task.FromResult(0);
        }

        public async Task<IdentityResult> UpdateAsync(TRole role, CancellationToken cancellationToken)
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            TRole result = await _repository.UpdateAsync(role);

            return result is null
                ? IdentityResult.Success
                : IdentityResult.Failed();
        }

        public void Dispose()
        {
            _disposed = true;
            _repository.Dispose();
        }

        private void ThrowIfDisposed()
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        #endregion IRoleStore Implementation

        #region IRoleClaimStore Implementation

        public async Task<IList<Claim>> GetClaimsAsync(TRole role, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            return role.Claims.Where(rc => rc.RoleId.Equals(role.Id)).Select(c => new Claim(c.ClaimType, c.ClaimValue)).ToList();

        }

        public Task AddClaimAsync(TRole role, Claim claim, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            claim.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            role.Claims.Add(new RoleClaim
            {
                RoleId = role.Id,
                ClaimType = claim.Type,
                ClaimValue = claim.Value
            });

            return Task.FromResult(0);
        }

        public Task RemoveClaimAsync(TRole role, Claim claim, CancellationToken cancellationToken = default(CancellationToken))
        {
            ThrowIfDisposed();
            role.ThrowIfNull();
            claim.ThrowIfNull();
            cancellationToken.ThrowIfCancellationRequested();

            role.Claims.RemoveAll(rc => rc.ClaimType == claim.Type && rc.ClaimValue == claim.Value);

            return Task.FromResult(0);

        }

        #endregion IRoleClaimStore Implementation

    }
}

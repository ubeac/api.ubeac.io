﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using uBeac.IdentityServer.Models;
using uBeac.IdentityServer.Repositories;

namespace uBeac.IdentityServer.Controllers
{
    [Route("[controller]/[action]")]
    public class UserController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IUserRepository<User> _userRepository;

        public UserController(UserManager<User> userManager, SignInManager<User> signInManager, IUserRepository<User> userRepository)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _userRepository = userRepository;
        }

        [HttpGet]
        public JsonResult GetCurrentClaims()
        {
            return new JsonResult(from c in User.Claims select new { c.Type, c.Value });
        }

        [HttpPut]
        public async Task<ApiResult<UserRegisterViewModel>> Register([FromBody]  UserRegisterInputModel model)
        {
            User user = new User
            {
                Firstname = model.Firstname,
                Lastname = model.Lastname,
                UserName = model.Username,
                Email = model.Email,
                Roles = model.Roles
            };

            var result = await _userManager.CreateAsync(user, model.Password);
            if (result.Succeeded)
            {
                return ApiResult<UserRegisterViewModel>.GetOK(new UserRegisterViewModel(user));
            }
            else
            {
                return ApiResult<UserRegisterViewModel>.GetNOK(ApiCodes.InvalidData, "", result.Errors);
            }
        }

        [HttpPost]
        public async Task<ApiResult<string>> ChangePassword([FromBody]  ChangePasswordInputModel model)
        {
            User user = await _userManager.FindByIdAsync(model.Id);
            user.ThrowIfNull();

            var result = await _userManager.ChangePasswordAsync(user, model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                return ApiResult<string>.GetOK();
            }
            else
            {
                return ApiResult<string>.GetNOK(ApiCodes.InvalidData, "", result.Errors);
            }
        }

        [HttpPost]
        public async Task<ApiResult<string>> Update([FromBody]  UserUpdateInputModel model)
        {
            var user = await _userManager.FindByIdAsync(model.Id);
            user.ThrowIfNull();

            user.Firstname = model.Firstname;
            user.Lastname = model.Lastname;
            user.UserName = model.Username;
            user.Email = model.Email;
            user.IsDeleted = model.IsDeleted;
            user.Roles = model.Roles;

            var result = await _userManager.UpdateAsync(user);
            if (result.Succeeded)
            {
                return ApiResult<string>.GetOK();
            }
            else
            {
                return ApiResult<string>.GetNOK(ApiCodes.InvalidData, "", result.Errors);
            }
        }

        [HttpGet]
        public async Task<ApiResult<List<UserViewModel>>> GetAll()
        {
            var users = await _userRepository.GetAllAsync();
            var usersViewModel = users.Select(p => new UserViewModel(p)).ToList();
            var result = ApiResult<List<UserViewModel>>.GetOK(usersViewModel);
            return result;
        }

        [HttpGet]
        public async Task<ApiResult<UserViewModel>> GetById(string userId)
        {
            userId.ThrowIfNull();
            var user = await _userRepository.GetByIdAsync(userId);
            var userViewModel = new UserViewModel(user);
            var result = ApiResult<UserViewModel>.GetOK(userViewModel);
            return result;
        }

        [HttpDelete]
        public async Task<ApiResult<string>> Remove([FromBody]  string userId)
        {
            userId.ThrowIfNull();
            var user = await _userRepository.GetByIdAsync(userId);
            user.ThrowIfNull();
            user.IsDeleted = true;
            var result = await _userManager.UpdateAsync(user);
            if (result.Succeeded)
            {
                return ApiResult<string>.GetOK();
            }
            else
            {
                return ApiResult<string>.GetNOK(ApiCodes.InvalidData, "", result.Errors);
            }
        }

    }

    public class UserViewModel : UserUpdateInputModel
    {
        public UserViewModel()
        {
        }
        public UserViewModel(User user)
        {
            Id = user.Id;
            Username = user.UserName;
            Email = user.Email;
            Firstname = user.Firstname;
            Lastname = user.Lastname;
            IsDeleted = user.IsDeleted;
            Roles = user.Roles;
        }
    }

    public class UserRegisterViewModel : UserRegisterInputModel
    {
        public string Id { get; set; }

        public UserRegisterViewModel()
        {
        }
        public UserRegisterViewModel(User user)
        {
            Id = user.Id;
            Username = user.UserName;
            user.Email = user.Email;
            Firstname = user.Firstname;
            Lastname = user.Lastname;
            Roles = user.Roles;
        }
    }

    public class UserRegisterInputModel
    {
        [StringLength(50, MinimumLength = 2)]
        public string Username { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string Firstname { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string Lastname { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        public List<string> Roles { get; set; }

        public UserRegisterInputModel()
        {
            Roles = new List<string>();
        }

    }

    public class UserUpdateInputModel
    {
        public string Id { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string Username { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string Firstname { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string Lastname { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public bool IsDeleted { get; set; }

        public List<string> Roles { get; set; }

        public UserUpdateInputModel()
        {
            Roles = new List<string>();
        }

    }

    public class ChangePasswordInputModel
    {
        [Required]
        public string Id { get; set; }
        [Required]
        public string OldPassword { get; set; }
        [Required]
        public string NewPassword { get; set; }
    }

}

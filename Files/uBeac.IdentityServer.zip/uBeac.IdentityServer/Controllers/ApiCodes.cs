﻿namespace uBeac.IdentityServer.Controllers
{
    public enum ApiCodes
    {
        OK = 0,
        InvalidData = 1,
        NotFound = 2,
        BadRequest = 400,
        UnhandledException = 500
    }
}
